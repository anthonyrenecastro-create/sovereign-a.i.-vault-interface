
import React, { useEffect, useRef, useState, useMemo } from 'react';
import { XCircle, Sparkles, Copy, Check, Download, Image as ImageIcon, ChevronDown, ChevronRight, Maximize, Trash2, Activity, BarChart } from 'lucide-react';

interface Props {
  output: {
    text: string;
    isError: boolean;
    sourceCode?: string;
    language?: string;
    images?: { name: string, data: string, mimeType: string }[];
  } | null;
  onClear: () => void;
  onFixError: (code: string, error: string, language: string) => void;
  onViewImage: (img: { name: string, data: string, mimeType: string }) => void;
  onRemoveImage: (index: number) => void;
}

export const OutputPanel: React.FC<Props> = ({ output, onClear, onFixError, onViewImage, onRemoveImage }) => {
  const endRef = useRef<HTMLDivElement>(null);
  const [copied, setCopied] = useState(false);
  const [areImagesCollapsed, setAreImagesCollapsed] = useState(false);

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [output?.text]);

  const handleCopy = async () => {
    if (output?.text) {
        await navigator.clipboard.writeText(output.text);
        setCopied(true);
        setTimeout(() => setCopied(false), 2000);
    }
  };

  const handleDownloadImage = (e: React.MouseEvent, img: { name: string, data: string, mimeType: string }) => {
      e.stopPropagation();
      const link = document.createElement('a');
      link.href = `data:${img.mimeType};base64,${img.data}`;
      link.download = img.name;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
  };

  // Detect SPI Output
  const spiMetrics = useMemo(() => {
      if (!output?.text) return null;
      // Check for magic marker
      const marker = "__SPI_METRICS__:";
      const idx = output.text.indexOf(marker);
      if (idx !== -1) {
          try {
              const jsonStr = output.text.substring(idx + marker.length);
              // Try to extract just the JSON part (in case of trailing newlines)
              const jsonPart = jsonStr.split('\n')[0];
              return JSON.parse(jsonPart);
          } catch (e) { return null; }
      }
      
      // Fallback Regex parsing if marker is missing
      const syntropy = output.text.match(/Syntropy Level = ([\d\.]+)/);
      const pattern = output.text.match(/Pattern Strength = ([\d\.]+)/);
      const memory = output.text.match(/Memory State Norm = ([\d\.]+)/);
      
      if (syntropy) {
          return {
              syntropy_level: parseFloat(syntropy[1]),
              pattern_strength: pattern ? parseFloat(pattern[1]) : 0,
              memory_state_norm: memory ? parseFloat(memory[1]) : 0
          };
      }
      return null;
  }, [output?.text]);

  if (!output) {
      return (
          <div className="flex items-center justify-center h-full text-gray-500 text-xs italic select-none">
              Run code to see output here...
          </div>
      );
  }

  return (
    <div className="flex flex-col h-full font-mono text-xs bg-[#0f1117] relative">
        {/* Toolbar */}
        <div className="flex items-center justify-between px-3 py-2 bg-gray-800/50 border-b border-gray-700 shrink-0">
            <div className="flex items-center gap-2">
                <span className={`uppercase tracking-wider font-semibold ${output.isError ? 'text-red-400' : 'text-green-400'}`}>
                    {output.isError ? 'Execution Error' : 'Success'}
                </span>
                {output.isError && output.sourceCode && (
                    <button 
                        onClick={() => onFixError(output.sourceCode!, output.text, output.language || 'python')}
                        className="flex items-center gap-1.5 px-2 py-0.5 rounded bg-accent-600/10 text-accent-400 border border-accent-500/30 hover:bg-accent-600 hover:text-white transition-colors ml-2"
                    >
                        <Sparkles className="w-3 h-3" />
                        Fix with AI
                    </button>
                )}
            </div>
            <div className="flex items-center gap-1">
                <button onClick={handleCopy} className="p-1.5 text-gray-400 hover:text-white rounded hover:bg-gray-700 transition-colors" title="Copy Output">
                    {copied ? <Check className="w-3.5 h-3.5 text-green-400"/> : <Copy className="w-3.5 h-3.5"/>}
                </button>
                <button onClick={onClear} className="p-1.5 text-gray-400 hover:text-white rounded hover:bg-gray-700 transition-colors" title="Clear">
                    <XCircle className="w-3.5 h-3.5" />
                </button>
            </div>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-auto p-4 custom-scrollbar space-y-4">
            
            {/* SPI Visualization Dashboard */}
            {spiMetrics && (
                <div className="bg-gray-900 border border-gray-700 rounded-lg p-4 mb-4 shadow-lg relative overflow-hidden">
                    <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-blue-500 to-purple-500"></div>
                    <div className="flex items-center gap-2 mb-4">
                        <Activity className="w-4 h-4 text-blue-400 animate-pulse" />
                        <h3 className="text-sm font-bold text-white">Neural Engine State</h3>
                    </div>
                    
                    <div className="grid grid-cols-3 gap-4">
                        <div className="bg-gray-800 p-3 rounded border border-gray-700 flex flex-col items-center">
                            <span className="text-[10px] text-gray-400 uppercase">Syntropy</span>
                            <div className="text-xl font-bold text-blue-400 my-1">{(spiMetrics.syntropy_level * 100).toFixed(1)}%</div>
                            <div className="w-full h-1.5 bg-gray-700 rounded-full overflow-hidden">
                                <div className="h-full bg-blue-500 transition-all duration-1000" style={{ width: `${Math.min(spiMetrics.syntropy_level * 100, 100)}%` }}></div>
                            </div>
                        </div>
                        <div className="bg-gray-800 p-3 rounded border border-gray-700 flex flex-col items-center">
                            <span className="text-[10px] text-gray-400 uppercase">Pattern Str</span>
                            <div className="text-xl font-bold text-purple-400 my-1">{spiMetrics.pattern_strength.toFixed(2)}</div>
                            <div className="w-full h-1.5 bg-gray-700 rounded-full overflow-hidden">
                                <div className="h-full bg-purple-500 transition-all duration-1000" style={{ width: `${Math.min(spiMetrics.pattern_strength * 50, 100)}%` }}></div>
                            </div>
                        </div>
                        <div className="bg-gray-800 p-3 rounded border border-gray-700 flex flex-col items-center">
                            <span className="text-[10px] text-gray-400 uppercase">Memory</span>
                            <div className="text-xl font-bold text-green-400 my-1">{spiMetrics.memory_state_norm.toFixed(2)}</div>
                            <div className="w-full h-1.5 bg-gray-700 rounded-full overflow-hidden">
                                <div className="h-full bg-green-500 transition-all duration-1000" style={{ width: `${Math.min(spiMetrics.memory_state_norm * 10, 100)}%` }}></div>
                            </div>
                        </div>
                    </div>
                </div>
            )}

            {/* Text Output */}
            {output.text && (
                <pre className={`whitespace-pre-wrap break-words leading-relaxed ${output.isError ? 'text-red-300' : 'text-gray-300'}`}>
                    {output.text}
                </pre>
            )}
            
            {/* Image Output */}
            {output.images && output.images.length > 0 && (
                <div className="border-t border-gray-800 pt-4 mt-2">
                    <button 
                        onClick={() => setAreImagesCollapsed(!areImagesCollapsed)}
                        className="flex items-center gap-2 text-xs font-semibold text-gray-400 hover:text-white mb-3 w-full group"
                    >
                        {areImagesCollapsed ? <ChevronRight className="w-3.5 h-3.5"/> : <ChevronDown className="w-3.5 h-3.5"/>}
                        Generated Images ({output.images.length})
                        <span className="text-gray-600 font-normal text-[10px] group-hover:text-gray-500 transition-colors ml-auto">
                            {areImagesCollapsed ? 'Click to show' : 'Click to minimize'}
                        </span>
                    </button>
                    
                    {!areImagesCollapsed && (
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 animate-in slide-in-from-top-2 duration-200">
                            {output.images.map((img, idx) => (
                                <div key={idx} className="bg-gray-800/50 rounded-lg border border-gray-700 p-2 group relative hover:border-gray-600 transition-colors">
                                    <div className="aspect-video bg-gray-900 rounded mb-2 flex items-center justify-center overflow-hidden relative">
                                        <img 
                                            src={`data:${img.mimeType};base64,${img.data}`} 
                                            alt={img.name} 
                                            className="max-w-full max-h-full object-contain"
                                            loading="lazy"
                                        />
                                        {/* Overlay */}
                                        <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2">
                                            <button 
                                                onClick={() => onViewImage(img)}
                                                className="p-2 bg-gray-800 rounded-full hover:bg-accent-600 hover:text-white text-gray-300 transition-colors shadow-lg"
                                                title="Full Screen Preview"
                                            >
                                                <Maximize className="w-4 h-4" />
                                            </button>
                                            <button 
                                                onClick={(e) => { e.stopPropagation(); onRemoveImage(idx); }}
                                                className="p-2 bg-gray-800 rounded-full hover:bg-red-600 hover:text-white text-gray-300 transition-colors shadow-lg"
                                                title="Remove Image"
                                            >
                                                <Trash2 className="w-4 h-4" />
                                            </button>
                                        </div>
                                    </div>
                                    <div className="flex items-center justify-between px-1">
                                        <div className="flex items-center gap-1.5 overflow-hidden">
                                            <ImageIcon className="w-3 h-3 text-purple-400 shrink-0" />
                                            <span className="text-[10px] text-gray-400 truncate max-w-[100px]" title={img.name}>{img.name}</span>
                                        </div>
                                        <button 
                                            onClick={(e) => handleDownloadImage(e, img)}
                                            className="flex items-center gap-1 text-[10px] bg-gray-700 hover:bg-gray-600 text-white px-2 py-1 rounded transition-colors shadow-sm"
                                            title="Download to Disk"
                                        >
                                            <Download className="w-3 h-3" /> 
                                            <span>Save</span>
                                        </button>
                                    </div>
                                </div>
                            ))}
                        </div>
                    )}
                </div>
            )}

            <div ref={endRef} />
        </div>
    </div>
  );
};
