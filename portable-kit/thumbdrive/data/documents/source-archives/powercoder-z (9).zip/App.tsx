
import React, { useState, useRef, useEffect, useMemo } from 'react';
import { Message, GithubConfig, ToastType, ToastData, Attachment, EnvVar, FileNode, RuntimeMode } from './types';
import { streamGeminiResponse } from './services/geminiService';
import { GithubSettingsModal } from './components/GithubSettingsModal';
import { CodeBlock } from './components/CodeBlock';
import { TerminalPanel } from './components/TerminalPanel';
import { OutputPanel } from './components/OutputPanel';
import { DraggablePanel } from './components/DraggablePanel';
import { BridgePanel } from './components/BridgePanel';
import { FileSystemDirectoryHandle, getFileTree, readFileFromLocal } from './services/localFileSystem';
import { writeFileToVFS, runPythonScript, runPythonCode, createZipArchive, loadZipToVFS } from './services/pythonRuntime';
import { saveProjectSnapshot, getAllSnapshots, deleteSnapshot, ProjectSnapshot } from './services/projectStorage';
import { fetchRepoZip } from './services/githubService';
import { 
  Bot, Send, Settings, Github, User, Sparkles, StopCircle, ChevronDown, ChevronRight, Paperclip, X, FileText, 
  Image as ImageIcon, Database, HardDrive, Folder, FileCode, RefreshCw, Play, Terminal as TerminalIcon, Code2, 
  Loader2, Monitor, Mic, ChevronsLeft, ChevronsRight, Zap, Brain, Rocket, Cpu, Download, ZoomIn, ZoomOut, Maximize, Globe, Link, Server, Archive, Cloud, Trash2, Clock, Save
} from 'lucide-react';

const parseMessageContent = (content: string) => {
  const regex = /```(\w+)?\n([\s\S]*?)```/g;
  const parts = [];
  let lastIndex = 0;
  let match;
  while ((match = regex.exec(content)) !== null) {
    if (match.index > lastIndex) parts.push({ type: 'text', content: content.slice(lastIndex, match.index) });
    parts.push({ type: 'code', language: match[1] || 'text', content: match[2] });
    lastIndex = regex.lastIndex;
  }
  if (lastIndex < content.length) parts.push({ type: 'text', content: content.slice(lastIndex) });
  return parts;
};

const App: React.FC = () => {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 'welcome',
      role: 'model',
      content: window.electron 
        ? "Hello! I'm PowerCoder-Z Desktop. I have full access to your local system via Electron."
        : "Hello! I'm PowerCoder-Z. I'm a hybrid AI assistant running in the browser.",
      timestamp: Date.now()
    }
  ]);
  const [input, setInput] = useState('');
  const [attachments, setAttachments] = useState<Attachment[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [selectedModel, setSelectedModel] = useState<string>('gemini-2.5-flash');
  const [isThinkingEnabled, setIsThinkingEnabled] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const recognitionRef = useRef<any>(null);

  const [isTerminalOpen, setIsTerminalOpen] = useState(true);
  const [isScriptEditorOpen, setIsScriptEditorOpen] = useState(false);
  const [isOutputOpen, setIsOutputOpen] = useState(false);
  const [isBridgeOpen, setIsBridgeOpen] = useState(false); 
  const [viewingImage, setViewingImage] = useState<{ name: string, data: string, mimeType: string } | null>(null);
  const [imageZoom, setImageZoom] = useState(1);
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);
  const [toasts, setToasts] = useState<ToastData[]>([]);

  const [scriptContent, setScriptContent] = useState('# Write Python code here\nprint("Hello from Scratchpad")\n');
  const [isRunningScript, setIsRunningScript] = useState(false);
  const [lastScriptError, setLastScriptError] = useState<string | null>(null);

  const [outputData, setOutputData] = useState<{ 
      text: string; isError: boolean; sourceCode?: string; language?: string; images?: { name: string, data: string, mimeType: string }[] 
  } | null>(null);
  
  const bottomRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  const [savedConfigs, setSavedConfigs] = useState<GithubConfig[]>(() => {
    try { return JSON.parse(localStorage.getItem('powercoder_configs') || '[]'); } catch(e) { return []; }
  });
  const [activeConfigId, setActiveConfigId] = useState<string | null>(() => localStorage.getItem('powercoder_active_id'));
  const [envVars, setEnvVars] = useState<EnvVar[]>(() => {
      try { return JSON.parse(localStorage.getItem('powercoder_env_vars') || '[]'); } catch(e) { return []; }
  });
  
  const [localDirHandle, setLocalDirHandle] = useState<FileSystemDirectoryHandle | null>(null);
  const [virtualFileMap, setVirtualFileMap] = useState<Map<string, File> | null>(null);
  const [fileTree, setFileTree] = useState<FileNode[]>([]);
  const [isTreeLoading, setIsTreeLoading] = useState(false);
  const [expandedFolders, setExpandedFolders] = useState<Set<string>>(new Set());

  const [snapshots, setSnapshots] = useState<ProjectSnapshot[]>([]);
  const [isSavingSnapshot, setIsSavingSnapshot] = useState(false);
  const [isDownloadingRepo, setIsDownloadingRepo] = useState(false);

  useEffect(() => { refreshSnapshots(); }, []);
  useEffect(() => { if (!activeConfigId && savedConfigs.length > 0) setActiveConfigId(savedConfigs[0].id); }, [savedConfigs, activeConfigId]);
  useEffect(() => localStorage.setItem('powercoder_configs', JSON.stringify(savedConfigs)), [savedConfigs]);
  useEffect(() => localStorage.setItem('powercoder_env_vars', JSON.stringify(envVars)), [envVars]);
  useEffect(() => { if (activeConfigId) localStorage.setItem('powercoder_active_id', activeConfigId); else localStorage.removeItem('powercoder_active_id'); }, [activeConfigId]);
  useEffect(() => { setImageZoom(1); }, [viewingImage]);
  
  useEffect(() => { 
      if (localDirHandle) { setVirtualFileMap(null); refreshFileTree(); } 
      else if (!virtualFileMap) setFileTree([]);
  }, [localDirHandle]);

  const handleSetVirtualData = (data: { tree: FileNode[], map: Map<string, File> } | null) => {
      if (data) { setFileTree(data.tree); setVirtualFileMap(data.map); } 
      else { setVirtualFileMap(null); if (!localDirHandle) setFileTree([]); }
  };

  const refreshFileTree = async () => {
    if (!localDirHandle) return;
    setIsTreeLoading(true);
    try { const tree = await getFileTree(localDirHandle); setFileTree(tree); } 
    catch (e) { console.error("Failed to load tree", e); addToast("Failed to refresh file list", ToastType.ERROR); } 
    finally { setIsTreeLoading(false); }
  };

  const refreshSnapshots = async () => { try { const list = await getAllSnapshots(); setSnapshots(list); } catch (e) { console.error("Failed to load snapshots", e); } };
  const activeConfig = useMemo(() => savedConfigs.find(c => c.id === activeConfigId) || null, [savedConfigs, activeConfigId]);
  useEffect(() => { bottomRef.current?.scrollIntoView({ behavior: 'smooth' }); }, [messages]);

  useEffect(() => {
    if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
        const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
        recognitionRef.current = new SpeechRecognition();
        recognitionRef.current.continuous = true;
        recognitionRef.current.interimResults = true;
        recognitionRef.current.onresult = (event: any) => {
            let finalTranscript = '';
            for (let i = event.resultIndex; i < event.results.length; ++i) {
                if (event.results[i].isFinal) finalTranscript += event.results[i][0].transcript;
            }
            if (finalTranscript) setInput(prev => prev + (prev ? ' ' : '') + finalTranscript);
        };
        recognitionRef.current.onend = () => setIsListening(false);
        recognitionRef.current.onerror = (event: any) => { console.error("Speech Error", event.error); setIsListening(false); };
    }
  }, []);

  const toggleVoiceInput = () => {
      if (!recognitionRef.current) { addToast("Voice input not supported.", ToastType.ERROR); return; }
      if (isListening) { recognitionRef.current.stop(); setIsListening(false); } 
      else { recognitionRef.current.start(); setIsListening(true); }
  };

  const addToast = (message: string, type: ToastType) => {
    const id = Math.random().toString(36).substring(7);
    setToasts(prev => [...prev, { id, message, type }]);
    setTimeout(() => setToasts(prev => prev.filter(t => t.id !== id)), 3000);
  };

  const handleFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files) return;
    const newAttachments: Attachment[] = [];
    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      const isImage = file.type.startsWith('image/');
      const isPDF = file.type === 'application/pdf';
      const isDocx = file.type === 'application/vnd.openxmlformats-officedocument.wordprocessingml.document';
      const isTextFile = file.type.startsWith('text/') || ['.js','.py','.html','.json','.md','.txt','.ts','.tsx','.css','.csv'].some(ext => file.name.endsWith(ext));

      if (isImage || isPDF) {
        const base64 = await new Promise<string>((resolve) => {
            const reader = new FileReader();
            reader.onload = () => resolve((reader.result as string).split(',')[1]);
            reader.readAsDataURL(file);
        });
        newAttachments.push({ id: Math.random().toString(36), type: 'file', mimeType: file.type, data: base64, name: file.name, isText: false });
      } else if (isDocx && window.mammoth) {
          try {
             const arrayBuffer = await file.arrayBuffer();
             const result = await window.mammoth.extractRawText({ arrayBuffer });
             newAttachments.push({ id: Math.random().toString(36), type: 'file', mimeType: 'text/plain', data: result.value, name: file.name, isText: true });
          } catch(e) { addToast(`Failed to parse DOCX: ${file.name}`, ToastType.ERROR); }
      } else if (isTextFile || isDocx) {
        const text = await file.text();
        newAttachments.push({ id: Math.random().toString(36), type: 'file', mimeType: file.type || 'text/plain', data: text, name: file.name, isText: true });
      }
    }
    setAttachments(prev => [...prev, ...newAttachments]);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const fetchNodeContent = async (node: FileNode) => {
      if (localDirHandle) return await readFileFromLocal(localDirHandle, node.path);
      if (virtualFileMap) { const f = virtualFileMap.get(node.path); if(f) return { content: await f.text(), mimeType: f.type || 'text/plain' }; }
      return null;
  };

  const handleAttachLocalFile = async (node: FileNode) => {
      try {
          const result = await fetchNodeContent(node);
          if (!result) return;
          setAttachments(prev => [...prev, { id: Math.random().toString(36), type: 'file', mimeType: result.mimeType, data: result.content, name: node.name, isText: true }]);
          addToast(`Attached ${node.name}`, ToastType.SUCCESS);
      } catch (e: any) { addToast(`Error: ${e.message}`, ToastType.ERROR); }
  };

  const handleRunLocalFile = async (node: FileNode, e: React.MouseEvent) => {
      e.stopPropagation();
      if (!node.name.endsWith('.py')) return addToast("Only Python files executable", ToastType.INFO);
      if (!isTerminalOpen) setIsTerminalOpen(true);
      try {
          const result = await fetchNodeContent(node);
          if (result) { await writeFileToVFS(node.path, result.content); await runPythonScript(node.path, envVars); }
      } catch (e: any) { addToast(`Execution failed: ${e.message}`, ToastType.ERROR); }
  };

  const handleRunScript = async () => {
      if (!scriptContent.trim()) return;
      setIsRunningScript(true); setLastScriptError(null);
      if (!isTerminalOpen) setIsTerminalOpen(true);
      try {
          const result = await runPythonCode(scriptContent, envVars, 'browser');
          if (result) {
             setOutputData({ text: result.text || "Script executed", isError: false, sourceCode: scriptContent, language: 'python', images: result.images });
             if (result.images && result.images.length > 0) setIsOutputOpen(true);
             setIsOutputOpen(true); 
          }
      } catch (e: any) { setLastScriptError(e.message); addToast("Script error", ToastType.ERROR); } 
      finally { setIsRunningScript(false); }
  };

  const handleSpiderResult = (url: string, content: string) => {
      setIsBridgeOpen(false);
      const prompt = `I have crawled the website: ${url}\n\nHere is the content:\n\`\`\`\n${content}\n\`\`\`\n\nPlease analyze this data.`;
      handleSendMessage(prompt);
  };
  
  const handleZipDownload = async () => {
      if (!isTerminalOpen) setIsTerminalOpen(true);
      await createZipArchive('browser');
  };

  const handleDownloadRepo = async () => {
      if (!activeConfig) return;
      setIsDownloadingRepo(true);
      try {
          const result = await fetchRepoZip(activeConfig);
          if (result.success && result.data) {
              const blob = new Blob([result.data], { type: 'application/zip' });
              const url = URL.createObjectURL(blob);
              const a = document.createElement('a');
              a.href = url; a.download = `${activeConfig.repo}-${activeConfig.branch}.zip`;
              document.body.appendChild(a); a.click(); document.body.removeChild(a); URL.revokeObjectURL(url);
              addToast(`Downloaded ${activeConfig.repo}`, ToastType.SUCCESS);
          } else { throw new Error(result.message); }
      } catch (e: any) {
          const manualUrl = `https://github.com/${activeConfig.owner}/${activeConfig.repo}/archive/refs/heads/${activeConfig.branch}.zip`;
          if (confirm(`Download failed (${e.message}).\n\nClick OK to download manually from GitHub.`)) { window.open(manualUrl, '_blank'); }
      } finally { setIsDownloadingRepo(false); }
  };

  const handleSaveSnapshot = async () => {
      setIsSavingSnapshot(true);
      if (!isTerminalOpen) setIsTerminalOpen(true);
      try {
          const blob = await createZipArchive('browser', true);
          if (blob && blob instanceof Blob) {
              const name = prompt("Enter snapshot name:", `Project ${new Date().toLocaleTimeString()}`);
              if (name) { await saveProjectSnapshot(name, blob); await refreshSnapshots(); addToast("Snapshot saved to Library", ToastType.SUCCESS); }
          } else { addToast("Failed to create zip blob", ToastType.ERROR); }
      } catch (e: any) { addToast(e.message, ToastType.ERROR); } finally { setIsSavingSnapshot(false); }
  };

  const handleRestoreSnapshot = async (s: ProjectSnapshot) => {
      if (confirm(`Replace current workspace with "${s.name}"? Unsaved changes will be lost.`)) {
          if (!isTerminalOpen) setIsTerminalOpen(true);
          try { const buffer = await s.blob.arrayBuffer(); await loadZipToVFS(buffer); addToast(`Restored "${s.name}"`, ToastType.SUCCESS); } 
          catch(e) { addToast("Failed to restore", ToastType.ERROR); }
      }
  };

  const handleDeleteSnapshot = async (id: string, e: React.MouseEvent) => {
      e.stopPropagation();
      if (confirm("Delete this snapshot?")) { await deleteSnapshot(id); await refreshSnapshots(); }
  };

  const handleSendMessage = async (manualContent?: string) => {
    const contentToSend = manualContent || input;
    if ((!contentToSend.trim() && attachments.length === 0) || isLoading) return;
    const userMsg: Message = { id: Date.now().toString(), role: 'user', content: contentToSend, timestamp: Date.now(), attachments: manualContent ? [] : [...attachments] };
    setMessages(prev => [...prev, userMsg]);
    if (!manualContent) { setInput(''); setAttachments([]); }
    setIsLoading(true);
    try {
      const modelMsgId = (Date.now() + 1).toString();
      setMessages(prev => [...prev, { id: modelMsgId, role: 'model', content: '', timestamp: Date.now(), isStreaming: true }]);
      const result = await streamGeminiResponse(messages, userMsg.content, userMsg.attachments || [], selectedModel, isThinkingEnabled ? 16384 : 0);
      let fullText = '';
      for await (const chunk of result) {
        fullText += chunk.text || '';
        setMessages(prev => prev.map(msg => msg.id === modelMsgId ? { ...msg, content: fullText } : msg));
      }
      setMessages(prev => prev.map(msg => msg.id === modelMsgId ? { ...msg, isStreaming: false } : msg));
      if (localDirHandle) refreshFileTree();
    } catch (error) {
      addToast("Failed to generate response.", ToastType.ERROR);
      setMessages(prev => prev.map(msg => msg.isStreaming ? { ...msg, content: msg.content + "\n[Error]", isStreaming: false } : msg));
    } finally { setIsLoading(false); }
  };

  const handleFixError = (code: string, errorMsg: string, language: string = 'python') => {
      handleSendMessage(`I ran this ${language} code and got an error:\n\`\`\`${language}\n${code}\n\`\`\`\nError: ${errorMsg}\n\nPlease fix it.`);
  };

  return (
    <div className="flex h-screen bg-gray-900 text-gray-100 font-sans overflow-hidden select-none">
       {/* Background */}
       <div className="absolute inset-0 z-0 pointer-events-none opacity-50 bg-repeat" style={{ backgroundImage: "url('data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIyMCIgaGVpZ2h0PSIyMCIgZmlsbD0ibm9uZSI+PHBhdGggZmlsbD0iIzIzMjYyRiIgZD0iTTAgMGgyMHYyMEgwVjB6Ii8+PHBhdGggZmlsbD0iIzFCMUUyMyIgZD0iTTAgMGgxMHYxMEgwVjB6bTEwIDEwaDEwdjEwSDEwVjEweiIvPjwvc3ZnPg==')" }}></div>
      
      <aside className={`${isSidebarCollapsed ? 'w-16' : 'w-80'} bg-gray-900 border-r border-gray-800 flex flex-col hidden md:flex shrink-0 transition-all duration-300 ease-in-out relative z-30`}>
        <div className="p-4 border-b border-gray-800 flex items-center gap-3 shrink-0 justify-between app-drag-region">
           <div className="flex items-center gap-3">
             <div className="w-8 h-8 bg-gradient-to-br from-blue-500 to-purple-600 rounded-lg flex items-center justify-center shrink-0 shadow-lg">
               <Bot className="text-white w-5 h-5" />
             </div>
             {!isSidebarCollapsed && (
               <div>
                 <h1 className="font-bold text-lg bg-clip-text text-transparent bg-gradient-to-r from-blue-400 to-purple-400 whitespace-nowrap">PowerCoder-Z</h1>
                 {window.electron && <span className="text-[9px] text-green-400 font-mono uppercase tracking-wider">Desktop Pro</span>}
               </div>
             )}
           </div>
           <button onClick={() => setIsSidebarCollapsed(!isSidebarCollapsed)} className="text-gray-500 hover:text-white"><ChevronsRight className={`w-4 h-4 transition-transform ${!isSidebarCollapsed ? 'rotate-180' : ''}`}/></button>
        </div>
        
        <div className="flex-1 overflow-y-auto custom-scrollbar p-4 space-y-6">
            {/* Project Snapshots Section */}
            <div className="space-y-2">
                 {!isSidebarCollapsed && <div className="flex items-center justify-between text-xs font-semibold text-gray-500 uppercase tracking-wider"><div className="flex items-center gap-2"><Cloud className="w-3 h-3" /><span>Project Snapshots</span></div><button onClick={handleSaveSnapshot} disabled={isSavingSnapshot} title="Save Current State"><Save className={`w-3 h-3 ${isSavingSnapshot ? 'animate-pulse' : ''}`} /></button></div>}
                 {!isSidebarCollapsed ? (
                     <div className="bg-gray-900/50 border border-gray-800 rounded-lg min-h-[60px] max-h-[150px] overflow-y-auto p-2 space-y-1">
                         {snapshots.length === 0 && <div className="text-gray-600 text-[10px] italic text-center">No saved snapshots</div>}
                         {snapshots.map(s => (
                             <div key={s.id} onClick={() => handleRestoreSnapshot(s)} className="flex items-center justify-between p-2 rounded hover:bg-gray-800 cursor-pointer group">
                                 <div className="flex items-center gap-2 min-w-0">
                                     <Clock className="w-3 h-3 text-blue-400" />
                                     <div className="truncate">
                                         <div className="text-xs text-gray-300 truncate">{s.name}</div>
                                         <div className="text-[10px] text-gray-500">{(s.size / 1024).toFixed(1)}KB</div>
                                     </div>
                                 </div>
                                 <button onClick={(e) => handleDeleteSnapshot(s.id, e)} className="text-gray-600 hover:text-red-400 opacity-0 group-hover:opacity-100"><Trash2 className="w-3 h-3"/></button>
                             </div>
                         ))}
                     </div>
                 ) : (
                     <button onClick={() => setIsSidebarCollapsed(false)} className="w-full flex justify-center p-2 hover:bg-gray-800 rounded"><Cloud className="w-5 h-5 text-gray-400"/></button>
                 )}
            </div>

            {/* File Explorer Section */}
            <div className="space-y-2">
                {!isSidebarCollapsed && <div className="flex items-center justify-between text-xs font-semibold text-gray-500 uppercase tracking-wider"><div className="flex items-center gap-2"><HardDrive className="w-3 h-3" /><span>Files</span></div><div className="flex gap-1">{localDirHandle && <button onClick={refreshFileTree} title="Refresh"><RefreshCw className={`w-3 h-3 ${isTreeLoading ? 'animate-spin' : ''}`} /></button>}<button onClick={handleZipDownload} title="Download Zip"><Archive className="w-3 h-3" /></button></div></div>}
                {(localDirHandle || virtualFileMap) ? (
                    <div className={`bg-gray-900/50 border border-gray-800 rounded-lg min-h-[100px] text-sm font-mono ${isSidebarCollapsed ? 'p-1' : 'p-2'}`}>{fileTree.length > 0 ? (fileTree.map((node) => <div key={node.path} style={{ paddingLeft: 0 }}>{node.kind === 'directory' ? <div className="flex items-center gap-1.5 py-1 text-gray-400 hover:text-white cursor-pointer select-none" onClick={() => { const next = new Set(expandedFolders); if (next.has(node.path)) next.delete(node.path); else next.add(node.path); setExpandedFolders(next); }}><ChevronRight className={`w-3.5 h-3.5 transition-transform ${expandedFolders.has(node.path) ? 'rotate-90' : ''}`} /><Folder className="w-3.5 h-3.5 text-accent-500" /><span className={`text-xs truncate ${isSidebarCollapsed ? 'hidden' : ''}`}>{node.name}</span></div> : <div className="flex items-center gap-1.5 py-1 text-gray-400 hover:text-white hover:bg-gray-800/50 cursor-pointer rounded px-1 group" onClick={() => handleAttachLocalFile(node)}><FileCode className="w-3.5 h-3.5 text-gray-500 group-hover:text-accent-400" /><span className={`text-xs truncate flex-1 ${isSidebarCollapsed ? 'hidden' : ''}`}>{node.name}</span>{!isSidebarCollapsed && <div className="flex opacity-0 group-hover:opacity-100 gap-1"><Play className="w-3 h-3 text-green-400 hover:text-green-300" onClick={(e) => handleRunLocalFile(node, e)} /></div>}</div>}</div>)) : !isSidebarCollapsed && <div className="text-gray-500 italic text-xs p-2">Empty directory</div>}</div>
                ) : (
                    !isSidebarCollapsed ? <button onClick={() => setIsSettingsOpen(true)} className="w-full py-3 border border-dashed border-gray-700 rounded-lg text-gray-400 hover:text-white hover:border-gray-500 hover:bg-gray-800 transition-all text-xs flex flex-col items-center gap-1"><HardDrive className="w-4 h-4 mb-1" /><span>Connect Local Project</span></button> : <button onClick={() => setIsSettingsOpen(true)} className="w-full flex justify-center p-2 hover:bg-gray-800 rounded"><HardDrive className="w-5 h-5 text-gray-400"/></button>
                )}
            </div>

            {/* GitHub Section */}
            <div className="space-y-2">
                {!isSidebarCollapsed && <div className="flex items-center justify-between text-xs font-semibold text-gray-500 uppercase tracking-wider"><div className="flex items-center gap-2"><Github className="w-3 h-3" /><span>Repository</span></div>{activeConfig && <div className="flex items-center gap-1"><button onClick={handleDownloadRepo} className="text-gray-500 hover:text-white" title="Download Repo Zip"><Download className={`w-3 h-3 ${isDownloadingRepo ? 'animate-bounce' : ''}`} /></button><div className="w-2 h-2 bg-green-500 rounded-full"></div></div>}</div>}
                {activeConfig ? (!isSidebarCollapsed ? <div className="bg-gray-800 rounded-lg p-3 border border-gray-700 shadow-sm"><div className="text-sm font-medium text-white truncate">{activeConfig.repo}</div><div className="text-xs text-gray-400 truncate">{activeConfig.owner}</div><div className="flex items-center gap-2 mt-2 pt-2 border-t border-gray-700"><span className="px-1.5 py-0.5 bg-gray-700 rounded text-[10px] font-mono text-gray-300">{activeConfig.branch}</span><span className="text-[10px] text-green-400 flex items-center gap-1"><Globe className="w-2.5 h-2.5"/> Connected</span></div></div> : <div className="flex justify-center"><div className="relative"><Github className="w-5 h-5 text-white"/><div className="absolute -top-1 -right-1 w-2 h-2 bg-green-500 rounded-full border border-gray-900"></div></div></div>) : (!isSidebarCollapsed ? <button onClick={() => setIsSettingsOpen(true)} className="w-full py-2 bg-gray-800/50 hover:bg-gray-800 border border-gray-700 rounded-lg text-gray-400 hover:text-white text-xs transition-colors">Configure GitHub</button> : <button onClick={() => setIsSettingsOpen(true)} className="w-full flex justify-center p-2 hover:bg-gray-800 rounded"><Github className="w-5 h-5 text-gray-500"/></button>)}
            </div>
        </div>

        <div className="p-4 border-t border-gray-800 bg-gray-900/50 space-y-2 shrink-0">
           <button onClick={() => setIsTerminalOpen(!isTerminalOpen)} className={`w-full flex items-center justify-center gap-2 py-2 border rounded-lg text-xs font-medium ${isTerminalOpen ? 'bg-accent-600/10 border-accent-500/50 text-accent-400' : 'bg-gray-800 border-transparent text-gray-300'}`}>{!isSidebarCollapsed && <span>Terminal</span>}<TerminalIcon className="w-4 h-4" /></button>
           <button onClick={() => setIsOutputOpen(!isOutputOpen)} className={`w-full flex items-center justify-center gap-2 py-2 border rounded-lg text-xs font-medium ${isOutputOpen ? 'bg-green-600/10 border-green-500/50 text-green-400' : 'bg-gray-800 border-transparent text-gray-300'}`}>{!isSidebarCollapsed && <span>Output</span>}<Monitor className="w-4 h-4" /></button>
           <button onClick={() => setIsScriptEditorOpen(!isScriptEditorOpen)} className={`w-full flex items-center justify-center gap-2 py-2 border rounded-lg text-xs font-medium ${isScriptEditorOpen ? 'bg-purple-600/10 border-purple-500/50 text-purple-400' : 'bg-gray-800 border-transparent text-gray-300'}`}>{!isSidebarCollapsed && <span>Scratchpad</span>}<Code2 className="w-4 h-4" /></button>
        </div>
      </aside>

      <main className="flex-1 relative flex flex-col min-w-0 bg-gray-900 z-0">
        <div className="absolute inset-0 overflow-y-auto p-4 md:p-8 space-y-6 scroll-smooth pb-40">
          {messages.map((msg) => (
            <div key={msg.id} className={`flex gap-4 max-w-5xl mx-auto ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
              {msg.role === 'model' && <div className="w-8 h-8 rounded-full bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center shrink-0 mt-1 shadow-lg"><Sparkles className="w-4 h-4 text-white" /></div>}
              <div className={`flex-1 min-w-0 max-w-[85%] flex flex-col gap-2 ${msg.role === 'user' ? 'items-end' : 'items-start'}`}>
                {msg.attachments && msg.attachments.length > 0 && <div className="flex flex-wrap gap-2 mb-1">{msg.attachments.map(att => <div key={att.id} className="flex items-center gap-2 bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-xs">{att.type === 'image' ? <ImageIcon className="w-3 h-3 text-purple-400"/> : <FileText className="w-3 h-3 text-blue-400"/>}<span className="max-w-[150px] truncate text-gray-300">{att.name}</span></div>)}</div>}
                <div className={`${msg.role === 'user' ? 'bg-gray-800 text-white rounded-2xl rounded-tr-sm px-4 py-3' : 'w-full'}`}>{msg.role === 'user' ? <p className="whitespace-pre-wrap">{msg.content}</p> : <div className="text-gray-300 leading-7">{parseMessageContent(msg.content).map((part, idx) => <React.Fragment key={idx}>{part.type === 'text' ? <p className="whitespace-pre-wrap mb-4">{part.content}</p> : <CodeBlock language={part.language} code={part.content.trim()} githubConfig={activeConfig} envVars={envVars} addToast={addToast} localDirHandle={localDirHandle} onOutput={(d) => { setOutputData(d); setIsOutputOpen(true); }} />}</React.Fragment>)}{msg.isStreaming && <span className="inline-block w-2 h-4 ml-1 bg-accent-500 animate-pulse align-middle"></span>}</div>}</div>
              </div>
              {msg.role === 'user' && <div className="w-8 h-8 rounded-full bg-gray-700 flex items-center justify-center shrink-0 mt-1"><User className="w-4 h-4 text-gray-300" /></div>}
            </div>
          ))}
          <div ref={bottomRef} />
        </div>

        <DraggablePanel title="Chat Input" initialPosition={{ x: window.innerWidth / 2 - 300, y: window.innerHeight - 180 }} defaultWidth="w-[600px]" defaultHeight="h-[160px]" className="border-accent-500/30">
             <div className="p-3 h-full flex flex-col gap-2">
                 <div className="flex items-center gap-3 pb-2 border-b border-gray-700/50 px-1 mb-1">
                     <div className="flex bg-gray-800 p-0.5 rounded-lg"><button onClick={() => setSelectedModel('gemini-2.5-flash')} className={`flex items-center gap-1.5 px-3 py-1.5 rounded text-[10px] font-medium transition-all ${selectedModel === 'gemini-2.5-flash' ? 'bg-accent-600 text-white shadow-sm' : 'text-gray-400 hover:text-white'}`}><Zap className="w-3 h-3" /> Flash 2.5</button><button onClick={() => setSelectedModel('gemini-3-pro-preview')} className={`flex items-center gap-1.5 px-3 py-1.5 rounded text-[10px] font-medium transition-all ${selectedModel === 'gemini-3-pro-preview' ? 'bg-purple-600 text-white shadow-sm' : 'text-gray-400 hover:text-white'}`}><Rocket className="w-3 h-3" /> Pro 3.0</button></div>
                     <div className="h-4 w-[1px] bg-gray-700"></div>
                     <button onClick={() => setIsThinkingEnabled(!isThinkingEnabled)} className={`flex items-center gap-1.5 px-2 py-1 rounded text-[10px] font-medium border transition-colors ${isThinkingEnabled ? 'bg-teal-500/10 border-teal-500/30 text-teal-400' : 'border-transparent text-gray-500 hover:text-gray-300'}`}><Brain className="w-3 h-3" /> Thinking {isThinkingEnabled ? 'On' : 'Off'}</button>
                 </div>
                 {attachments.length > 0 && <div className="flex flex-wrap gap-2 shrink-0">{attachments.map(att => <div key={att.id} className="relative group bg-gray-800 border border-gray-700 rounded px-2 py-1 flex items-center gap-2 text-[10px]"><span className="truncate max-w-[100px] text-gray-300">{att.name}</span><button onClick={() => setAttachments(prev => prev.filter(a => a.id !== att.id))} className="hover:text-red-400"><X className="w-3 h-3"/></button></div>)}</div>}
                 <div className="flex items-end gap-2 h-full">
                    <button onClick={() => fileInputRef.current?.click()} className="p-2 rounded-lg text-gray-400 hover:text-white hover:bg-gray-800 transition-colors shrink-0 mb-1"><Paperclip className="w-5 h-5" /></button>
                    {!window.electron && <button onClick={() => setIsBridgeOpen(!isBridgeOpen)} className={`p-2 rounded-lg transition-colors shrink-0 mb-1 ${isBridgeOpen ? 'text-green-400 bg-green-900/30' : 'text-gray-400 hover:text-white hover:bg-gray-800'}`}><Globe className="w-5 h-5" /></button>}
                    <button onClick={toggleVoiceInput} className={`p-2 rounded-lg transition-colors shrink-0 mb-1 ${isListening ? 'bg-red-500 text-white animate-pulse' : 'text-gray-400 hover:text-white hover:bg-gray-800'}`}><Mic className="w-5 h-5" /></button>
                    <textarea value={input} onChange={(e) => setInput(e.target.value)} onKeyDown={(e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); handleSendMessage(); } }} placeholder="Type a message..." className="flex-1 bg-transparent border-none focus:ring-0 outline-none resize-none text-white placeholder-gray-600 h-full py-2" />
                    <button onClick={() => handleSendMessage()} disabled={(!input.trim() && attachments.length === 0) || isLoading} className="p-2 mb-1 rounded-lg bg-accent-600 text-white hover:bg-accent-500 disabled:opacity-50 disabled:hover:bg-accent-600 transition-all shrink-0">{isLoading ? <StopCircle className="w-5 h-5 animate-pulse" /> : <Send className="w-5 h-5" />}</button>
                 </div>
                 <input type="file" multiple ref={fileInputRef} onChange={handleFileSelect} className="hidden" accept=".pdf,.docx,.txt,.md,.js,.ts,.tsx,.py,.html,.css,.json,.csv,image/*" />
             </div>
        </DraggablePanel>

        {isTerminalOpen && <DraggablePanel title="Terminal (System)" onClose={() => setIsTerminalOpen(false)} initialPosition={{ x: window.innerWidth - 620, y: window.innerHeight - 350 }} defaultWidth="w-[600px]" defaultHeight="h-[300px]"><TerminalPanel envVars={envVars} githubConfig={activeConfig} /></DraggablePanel>}
        {isOutputOpen && <DraggablePanel title="Code Output" onClose={() => setIsOutputOpen(false)} initialPosition={{ x: window.innerWidth - 620, y: 100 }} defaultWidth="w-[600px]" defaultHeight="h-[300px]" className="border-green-500/30"><OutputPanel output={outputData} onClear={() => setOutputData(null)} onFixError={handleFixError} onViewImage={(img) => setViewingImage(img)} onRemoveImage={(i) => { if(outputData?.images) { const ni = [...outputData.images]; ni.splice(i, 1); setOutputData({...outputData, images: ni}); }}} /></DraggablePanel>}
        {isBridgeOpen && !window.electron && <DraggablePanel title="Crawler & Automation" onClose={() => setIsBridgeOpen(false)} initialPosition={{ x: 20, y: 100 }} defaultWidth="w-[400px]" defaultHeight="h-[500px]" className="border-green-500/30"><BridgePanel onAddSpiderResult={handleSpiderResult} /></DraggablePanel>}
        {viewingImage && <DraggablePanel title={`Preview: ${viewingImage.name}`} onClose={() => setViewingImage(null)} initialPosition={{ x: window.innerWidth / 2 - 250, y: window.innerHeight / 2 - 250 }} defaultWidth="w-[500px]" defaultHeight="h-[500px]" className="border-purple-500/50"><div className="flex flex-col h-full bg-black/90 relative group"><div className="absolute top-2 right-2 flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity z-10 bg-gray-900/80 p-1 rounded-lg backdrop-blur border border-gray-700 shadow-xl"><button onClick={() => setImageZoom(Math.max(0.1, imageZoom - 0.1))} className="p-1.5 text-gray-400 hover:text-white hover:bg-gray-700 rounded"><ZoomOut className="w-4 h-4"/></button><button onClick={() => setImageZoom(1)} className="p-1.5 text-gray-400 hover:text-white hover:bg-gray-700 rounded"><Maximize className="w-4 h-4"/></button><button onClick={() => setImageZoom(imageZoom + 0.1)} className="p-1.5 text-gray-400 hover:text-white hover:bg-gray-700 rounded"><ZoomIn className="w-4 h-4"/></button><div className="w-[1px] h-4 bg-gray-700 mx-1 self-center"></div><button onClick={() => { const link = document.createElement('a'); link.href = `data:${viewingImage.mimeType};base64,${viewingImage.data}`; link.download = viewingImage.name; document.body.appendChild(link); link.click(); document.body.removeChild(link); }} className="p-1.5 text-gray-400 hover:text-green-400 hover:bg-gray-700 rounded"><Download className="w-4 h-4"/></button><div className="w-[1px] h-4 bg-gray-700 mx-1 self-center"></div><button onClick={() => setViewingImage(null)} className="p-1.5 text-gray-400 hover:text-red-400 hover:bg-gray-700 rounded"><X className="w-4 h-4"/></button></div><div className="flex-1 flex items-center justify-center p-4 overflow-auto" style={{ backgroundImage: "url('data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIyMCIgaGVpZ2h0PSIyMCIgZmlsbD0ibm9uZSI+PHBhdGggZmlsbD0iIzIzMjYyRiIgZD0iTTAgMGgyMHYyMEgwVjB6Ii8+PHBhdGggZmlsbD0iIzFCMUUyMyIgZD0iTTAgMGgxMHYxMEgwVjB6bTEwIDEwaDEwdjEwSDEwVjEweiIvPjwvc3ZnPg==')" }}><img src={`data:${viewingImage.mimeType};base64,${viewingImage.data}`} alt={viewingImage.name} style={{ transform: `scale(${imageZoom})`, transition: 'transform 0.1s' }} className="max-w-full max-h-full object-contain shadow-2xl" draggable={false} /></div></div></DraggablePanel>}
        {isScriptEditorOpen && <DraggablePanel title="Scratchpad (Python)" onClose={() => setIsScriptEditorOpen(false)} initialPosition={{ x: 20, y: 100 }} defaultWidth="w-[400px]" defaultHeight="h-[400px]" className="border-purple-500/30"><div className="flex flex-col h-full"><div className="flex items-center justify-between px-3 py-1 bg-gray-900 border-b border-gray-800 text-[10px] text-gray-400"><div className="flex items-center gap-2"><span>Executes in {window.electron ? 'Electron Node.js' : 'global Pyodide env'}</span></div>{lastScriptError && <button onClick={() => handleFixError(scriptContent, lastScriptError)} className="flex items-center gap-1 text-red-400 hover:text-accent-400 transition-colors"><Sparkles className="w-3 h-3" /> Fix with AI</button>}</div><div className="flex-1 bg-gray-900 p-0 relative"><textarea value={scriptContent} onChange={(e) => setScriptContent(e.target.value)} className="w-full h-full bg-transparent p-3 text-sm font-mono text-gray-300 resize-none focus:outline-none focus:ring-0" spellCheck={false} /></div><div className="p-2 bg-gray-800/80 border-t border-gray-700 flex justify-end"><button onClick={handleRunScript} disabled={isRunningScript} className="flex items-center gap-2 px-3 py-1.5 bg-purple-600 hover:bg-purple-500 text-white text-xs font-medium rounded transition-colors disabled:opacity-50">{isRunningScript ? <Loader2 className="w-3.5 h-3.5 animate-spin"/> : <Play className="w-3.5 h-3.5"/>} Run in Terminal</button></div></div></DraggablePanel>}
        <div className="fixed bottom-4 right-4 z-50 flex flex-col gap-2 pointer-events-none">{toasts.map((toast) => <div key={toast.id} className={`pointer-events-auto px-4 py-3 rounded-lg shadow-xl border flex items-center gap-2 animate-in slide-in-from-right fade-in duration-300 ${toast.type === ToastType.SUCCESS ? 'bg-gray-800 border-green-500/50 text-green-400' : toast.type === ToastType.ERROR ? 'bg-gray-800 border-red-500/50 text-red-400' : 'bg-gray-800 border-blue-500/50 text-blue-400'}`}><span className="text-sm font-medium">{toast.message}</span></div>)}</div>
        <GithubSettingsModal isOpen={isSettingsOpen} onClose={() => setIsSettingsOpen(false)} savedConfigs={savedConfigs} activeConfigId={activeConfigId} onSetActive={setActiveConfigId} onAddConfig={(c) => { setSavedConfigs(p => [...p, c]); setActiveConfigId(c.id); }} onRemoveConfig={(id) => { setSavedConfigs(p => p.filter(c => c.id !== id)); if (activeConfigId === id) setActiveConfigId(null); }} envVars={envVars} onUpdateEnvVars={setEnvVars} localDirHandle={localDirHandle} onSetLocalDirHandle={setLocalDirHandle} onSetVirtualData={handleSetVirtualData} />
      </main>
    </div>
  );
};

export default App;