
import React from 'react';
import { useDraggable } from '../hooks/useDraggable';

interface WindowProps {
    id: string;
    title: string;
    children: React.ReactNode;
    className?: string;
    initialPosition: { x: number, y: number };
}

const Window: React.FC<WindowProps> = ({ id, title, children, className, initialPosition }) => {
    const { ref, style, handleMouseDown } = useDraggable(id, initialPosition);

    return (
        <div 
            ref={ref} 
            style={style} 
            className={`is-draggable bg-black/60 backdrop-blur-xl rounded-lg shadow-2xl shadow-indigo-900/50 ring-1 ring-violet-500/30 flex flex-col z-50 resizable-window ${className}`}
        >
            <div
                onMouseDown={handleMouseDown}
                className="h-10 bg-slate-900/60 rounded-t-lg flex-shrink-0 flex items-center justify-center cursor-move border-b border-violet-800/60"
            >
                <div className="flex gap-1.5 absolute left-3">
                    <div className="w-2.5 h-2.5 rounded-full bg-rose-500/40 border border-rose-500/60"></div>
                    <div className="w-2.5 h-2.5 rounded-full bg-amber-500/40 border border-amber-500/60"></div>
                    <div className="w-2.5 h-2.5 rounded-full bg-emerald-500/40 border border-emerald-500/60"></div>
                </div>
                <h3 className="text-[10px] font-black text-slate-400 select-none uppercase tracking-[0.3em]">{title}</h3>
            </div>
            <div className="flex-grow overflow-hidden flex flex-col relative">
                {children}
                {/* Visual Resize Handle (Filament) */}
                <div className="absolute bottom-0 right-0 w-3 h-3 pointer-events-none opacity-40">
                    <div className="w-full h-full border-r-2 border-b-2 border-violet-500 rounded-br-[4px]" />
                </div>
            </div>
        </div>
    );
};

export default Window;
