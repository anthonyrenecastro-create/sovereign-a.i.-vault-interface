
import React, { useState, useMemo, useRef, useEffect } from 'react';
import { useDraggable } from '../hooks/useDraggable';
import type { SubstrateMode, CustomSubstrate, SubstrateVantage } from '../types';

interface SubstrateCircleProps {
    currentMode: SubstrateMode;
    onModeChange: (mode: SubstrateMode) => void;
    customSubstrates: CustomSubstrate[];
    onAddCustom: (sub: CustomSubstrate) => void;
    onOpenFeed: () => void;
    vantages: SubstrateVantage[];
    activeVantage: SubstrateVantage | null;
    onVantageChange: (vantage: SubstrateVantage | null) => void;
    isScanning: boolean;
}

const BASE_MODES: { id: SubstrateMode; icon: string; label: string; color: string }[] = [
    { id: 'discover', icon: '🌐', label: 'Global', color: '#8b5cf6' },
    { id: 'academic', icon: '🎓', label: 'Academic', color: '#3b82f6' },
    { id: 'finance', icon: '📈', label: 'Finance', color: '#10b981' },
    { id: 'patents', icon: '📜', label: 'Patents', color: '#f59e0b' },
    { id: 'sports', icon: '⚽', label: 'Sports', color: '#ef4444' },
    { id: 'shopping', icon: '🛒', label: 'Shopping', color: '#ec4899' },
    { id: 'modes', icon: '🕸️', label: 'Modes', color: '#06b6d4' },
];

const SubstrateCircle: React.FC<SubstrateCircleProps> = ({ 
    currentMode, 
    onModeChange, 
    customSubstrates, 
    onAddCustom,
    onOpenFeed,
    vantages,
    activeVantage,
    onVantageChange,
    isScanning
}) => {
    const { ref, style, handleMouseDown } = useDraggable('substrate-circle', { x: window.innerWidth / 2 - 200, y: window.innerHeight - 440 });
    const containerRef = useRef<HTMLDivElement>(null);
    const [dimensions, setDimensions] = useState({ width: 400, height: 400 });
    const [searchTerm, setSearchTerm] = useState('');
    const [isAdding, setIsAdding] = useState(false);
    const [newLabel, setNewLabel] = useState('');
    const [newIcon, setNewIcon] = useState('🧠');

    useEffect(() => {
        const observer = new ResizeObserver((entries) => {
            for (let entry of entries) {
                setDimensions({
                    width: entry.contentRect.width,
                    height: entry.contentRect.height
                });
            }
        });
        if (containerRef.current) observer.observe(containerRef.current);
        return () => observer.disconnect();
    }, []);

    const allModes = useMemo(() => [
        ...BASE_MODES,
        ...customSubstrates.map(s => ({ id: 'custom' as SubstrateMode, icon: s.icon, label: s.label, color: '#64748b' }))
    ], [customSubstrates]);

    const filteredModes = allModes.filter(m => m.label.toLowerCase().includes(searchTerm.toLowerCase()));

    const handleCreate = () => {
        if (!newLabel) return;
        onAddCustom({
            id: `custom-${Date.now()}`,
            label: newLabel,
            icon: newIcon,
            instruction: `Focus all intelligence on the specialized domain of ${newLabel}. Prioritize depth in this specific substrate.`
        });
        setNewLabel('');
        setIsAdding(false);
    };

    // Calculate dynamic radii based on container size to keep components centered and scaled
    const baseRadius = Math.min(dimensions.width, dimensions.height) / 2;
    const outerRadius = baseRadius * 0.75;
    const innerRadius = baseRadius * 0.45;
    const centerIconSize = baseRadius * 0.15;

    return (
        <div 
            ref={ref} 
            style={style} 
            className="is-draggable pointer-events-auto z-[60]"
        >
            <div 
                ref={containerRef}
                style={{ width: `${dimensions.width}px`, height: `${dimensions.height}px` }}
                className="relative bg-slate-950/70 backdrop-blur-3xl border border-white/10 rounded-full flex items-center justify-center shadow-[0_0_100px_rgba(139,92,246,0.3)] transition-all duration-300 resize overflow-hidden min-w-[300px] min-h-[300px]"
            >
                <div 
                    onMouseDown={handleMouseDown}
                    className="absolute inset-0 cursor-move rounded-full z-0"
                />

                <div className="z-10 text-center px-4 w-[60%] flex flex-col items-center pointer-events-auto">
                    {!isAdding ? (
                        <>
                            <div className="absolute top-[12%] animate-pulse opacity-40">
                                {isScanning && <div className="text-[7px] text-violet-400 font-black tracking-[0.3em]">NEURAL SCAN ACTIVE</div>}
                            </div>
                            <input 
                                type="text"
                                value={searchTerm}
                                onChange={(e) => setSearchTerm(e.target.value)}
                                placeholder="Search Links..."
                                className="w-full bg-transparent border-b border-white/20 text-[9px] text-white text-center focus:outline-none focus:border-violet-500 transition-colors placeholder:text-slate-600 uppercase font-black mb-1"
                            />
                            <div className="text-[14px] font-black text-white uppercase tracking-tighter truncate max-w-full drop-shadow-[0_0_12px_rgba(139,92,246,0.8)]">
                                {currentMode}
                            </div>
                            <div className="text-[7px] text-slate-500 uppercase mt-0.5 font-bold">
                                {activeVantage ? `Vantage: ${activeVantage.label}` : 'Synaptic Hub'}
                            </div>
                            <div className="flex gap-2 mt-4">
                                <button 
                                    onClick={onOpenFeed}
                                    className="p-1.5 rounded-lg bg-violet-600/10 hover:bg-violet-600/30 text-violet-400 border border-violet-500/20 transition-all"
                                    title="Open Stream"
                                >
                                    <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3"><path d="M4 11a9 9 0 0 1 9 9"/><path d="M4 4a16 16 0 0 1 16 16"/><circle cx="5" cy="19" r="1"/></svg>
                                </button>
                                <button 
                                    onClick={() => setIsAdding(true)}
                                    className="px-3 py-1.5 rounded-lg bg-slate-800/50 hover:bg-violet-600/20 text-slate-400 hover:text-white text-[8px] font-black uppercase tracking-widest border border-white/5 transition-all"
                                >
                                    + Link
                                </button>
                            </div>
                        </>
                    ) : (
                        <div className="w-full space-y-2 p-3 bg-black/60 rounded-xl border border-white/10">
                            <input 
                                type="text" 
                                value={newLabel} 
                                onChange={(e) => setNewLabel(e.target.value)}
                                placeholder="Domain Label..."
                                className="w-full bg-slate-900/80 border border-white/10 p-2 text-[10px] text-white text-center rounded focus:outline-none focus:border-violet-500"
                            />
                             <div className="flex gap-1.5 justify-center">
                                {['🧠', '💼', '🔭', '📡', '⚡'].map(i => (
                                    <button key={i} onClick={() => setNewIcon(i)} className={`p-1 rounded transition-all ${newIcon === i ? 'bg-violet-500 scale-125' : 'bg-white/5 hover:bg-white/10'}`}>{i}</button>
                                ))}
                            </div>
                            <div className="flex gap-2">
                                <button onClick={handleCreate} className="flex-1 bg-violet-600 hover:bg-violet-500 text-[8px] py-1.5 rounded font-black transition-colors">INIT</button>
                                <button onClick={() => setIsAdding(false)} className="flex-1 bg-slate-800 hover:bg-slate-700 text-[8px] py-1.5 rounded font-black transition-colors">VOID</button>
                            </div>
                        </div>
                    )}
                </div>

                {filteredModes.map((mode, index) => {
                    const angle = (index / filteredModes.length) * Math.PI * 2;
                    const x = Math.cos(angle) * outerRadius;
                    const y = Math.sin(angle) * outerRadius;
                    const isActive = currentMode === mode.id;
                    const iconSize = Math.max(32, baseRadius * 0.12);

                    return (
                        <button
                            key={`${mode.id}-${index}`}
                            onClick={() => {
                                onModeChange(mode.id);
                                onVantageChange(null);
                            }}
                            className={`absolute rounded-full border flex items-center justify-center transition-all duration-300 hover:scale-125 hover:z-20 pointer-events-auto ${
                                isActive 
                                ? 'bg-white text-black border-white shadow-[0_0_30px_rgba(255,255,255,0.6)]' 
                                : 'bg-slate-900/90 border-white/10 text-white hover:border-violet-500 hover:shadow-[0_0_20px_rgba(139,92,246,0.5)] opacity-40 hover:opacity-100'
                            }`}
                            style={{ 
                                transform: `translate(${x}px, ${y}px)`,
                                width: `${iconSize}px`,
                                height: `${iconSize}px`,
                                fontSize: `${iconSize * 0.5}px`
                            }}
                        >
                            <span className="relative z-10">{mode.icon}</span>
                        </button>
                    );
                })}

                {vantages.map((vantage, index) => {
                    const angle = (index / vantages.length) * Math.PI * 2 - Math.PI / 2;
                    const x = Math.cos(angle) * innerRadius;
                    const y = Math.sin(angle) * innerRadius;
                    const isActive = activeVantage?.id === vantage.id;
                    const vantageSize = Math.max(24, baseRadius * 0.09);

                    return (
                        <button
                            key={vantage.id}
                            onClick={() => onVantageChange(isActive ? null : vantage)}
                            className={`absolute rounded-full border flex items-center justify-center transition-all duration-500 hover:scale-125 z-20 pointer-events-auto ${
                                isActive 
                                ? 'bg-violet-500 border-violet-300 text-white shadow-[0_0_20px_rgba(139,92,246,0.9)]' 
                                : 'bg-slate-800/80 border-violet-500/20 text-slate-300 hover:border-violet-400'
                            }`}
                            style={{ 
                                transform: `translate(${x}px, ${y}px)`,
                                width: `${vantageSize}px`,
                                height: `${vantageSize}px`,
                                fontSize: `${vantageSize * 0.5}px`
                            }}
                            title={vantage.description}
                        >
                            <span className="relative z-10">{vantage.icon}</span>
                        </button>
                    );
                })}

                <svg className="absolute inset-0 w-full h-full pointer-events-none overflow-visible">
                    <circle cx="50%" cy="50%" r={`${outerRadius}`} fill="none" stroke="rgba(139, 92, 246, 0.1)" strokeWidth="0.5" strokeDasharray="5 15" className="animate-[spin_40s_linear_infinite]" />
                    <circle cx="50%" cy="50%" r={`${innerRadius}`} fill="none" stroke="rgba(139, 92, 246, 0.2)" strokeWidth="1" strokeDasharray="10 10" className="animate-[spin_20s_linear_infinite_reverse]" />
                    {vantages.map((_, i) => (
                        <line 
                            key={`v-line-${i}`}
                            x1="50%" y1="50%" 
                            x2={`${50 + (innerRadius / dimensions.width * 200) * Math.cos((i / vantages.length) * Math.PI * 2 - Math.PI / 2)}%`} 
                            y2={`${50 + (innerRadius / dimensions.height * 200) * Math.sin((i / vantages.length) * Math.PI * 2 - Math.PI / 2)}%`} 
                            stroke="rgba(139, 92, 246, 0.15)" 
                            strokeWidth="0.5"
                        />
                    ))}
                </svg>

                {/* Visible Resize Handle */}
                <div className="absolute bottom-2 right-2 w-5 h-5 cursor-nwse-resize opacity-40 hover:opacity-100 transition-opacity flex items-end justify-end p-0.5">
                    <div className="w-1.5 h-1.5 border-r-2 border-b-2 border-violet-400 rounded-br-sm" />
                    <div className="absolute w-3 h-3 border-r border-b border-violet-400/50 rounded-br-sm -mr-1 -mb-1" />
                </div>
            </div>
        </div>
    );
};

export default SubstrateCircle;
