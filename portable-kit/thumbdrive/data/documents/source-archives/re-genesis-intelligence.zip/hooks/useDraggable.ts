// FIX: Import React to resolve the 'Cannot find namespace 'React'.' error.
import React, { useState, useCallback, useRef, useEffect } from 'react';

export function useDraggable(id: string, initialPosition: { x: number, y: number }) {
    const isDraggingRef = useRef(false);
    const posRef = useRef({ dx: 0, dy: 0 });
    const elRef = useRef<HTMLDivElement | null>(null);

    const [position, setPosition] = useState(() => {
        try {
            const saved = localStorage.getItem(`draggable-pos-${id}`);
            if (saved) return JSON.parse(saved);
        } catch (e) { /* ignore */ }
        return initialPosition;
    });
    
    useEffect(() => {
       localStorage.setItem(`draggable-pos-${id}`, JSON.stringify(position));
    }, [position, id]);

    const handleMouseDown = useCallback((e: React.MouseEvent<HTMLDivElement>) => {
        // Only drag with left mouse button, and not on inputs/buttons inside the handle
        if (e.button !== 0 || (e.target as HTMLElement).closest('button, input, select, textarea')) {
            return;
        }

        if (elRef.current) {
            isDraggingRef.current = true;
            const rect = elRef.current.getBoundingClientRect();
            posRef.current.dx = e.clientX - rect.left;
            posRef.current.dy = e.clientY - rect.top;
            
            // Bring to front
            document.querySelectorAll('.is-draggable').forEach(el => (el as HTMLElement).style.zIndex = '50');
            elRef.current.style.zIndex = '51';
        }
    }, []);
    
    const handleMouseUp = useCallback(() => {
        isDraggingRef.current = false;
    }, []);

    const handleMouseMove = useCallback((e: MouseEvent) => {
        if (isDraggingRef.current && elRef.current) {
            const x = e.clientX - posRef.current.dx;
            const y = e.clientY - posRef.current.dy;
            setPosition({ x, y });
        }
    }, []);

    useEffect(() => {
        document.addEventListener('mousemove', handleMouseMove);
        document.addEventListener('mouseup', handleMouseUp);
        return () => {
            document.removeEventListener('mousemove', handleMouseMove);
            document.removeEventListener('mouseup', handleMouseUp);
        };
    }, [handleMouseMove, handleMouseUp]);

    return {
        ref: elRef,
        style: {
            position: 'absolute' as const,
            left: `${position.x}px`,
            top: `${position.y}px`,
        },
        handleMouseDown,
    };
}