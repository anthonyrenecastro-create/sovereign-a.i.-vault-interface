
import React, { useState, useEffect, useRef, useCallback } from 'react';
import { useSimulation } from './hooks/useSimulation';
import { useSpeech } from './hooks/useSpeech';
import { generateImage, generateVideo } from './services/geminiService';
import { sendMessageToUniversalEngine, fetchSubstrateNews, fetchSubstrateVantages } from './services/modelGate';
import { analyzeText } from './services/backendService';
import type { Message, AppSettings, GeminiHistory, MediaType, ActiveEngine, SubstrateMode, CustomSubstrate, NewsItem, SubstrateVantage, EngineConfig, NeMoNode } from './types';
import { Role } from './types';
import { CHAT_HISTORY_KEY, SETTINGS_KEY, PERSONAS, BOND_KEY, CUSTOM_SUB_KEY, NEMO_NODES_KEY } from './constants';
import { stripMarkdown } from './utils/textUtils';
import { parsePdf, parseDocx, parseXlsx, fileToBase64, isVisualFile } from './utils/fileParser';

import ChatInterface from './components/ChatInterface';
import SimulationVisualizer from './components/SimulationVisualizer';
import SettingsPanel from './components/SettingsPanel';
import Avatar from './components/Avatar';
import MetricsPanel from './components/MetricsPanel';
import Window from './components/Window';
import NeuralHub from './components/NeuralHub';
import SubstrateCircle from './components/SubstrateCircle';
import FeedWindow from './components/FeedWindow';

const DEFAULT_ENGINE_CONFIGS: Record<ActiveEngine, EngineConfig> = {
    Nemotron: { apiKey: '', isActive: true }, // Nemotron primary reasoning
    Gemini: { apiKey: '', isActive: true },
    DeepSeek: { apiKey: '', isActive: false },
    Perplexity: { apiKey: '', isActive: false },
    Eden: { apiKey: '', isActive: false },
    Ollama: { apiKey: 'http://localhost:11434', isActive: false },
};

const DEFAULT_SETTINGS: AppSettings = {
    ai: { temperature: 0.8, maxOutputTokens: 2048 },
    simulation: { syntropyTarget: 0.5, initialMass: 1.0, initialCoupling: 0.1 },
    personaId: 'default',
    voiceURI: null,
    avatarUrl: null,
    visuals: { colorPalette: 'violet', particleDensity: 0.6, fractalComplexity: 0.4 },
    ambientSound: true,
    elevenLabsActive: true,
    voiceChangerMode: false,
    engineConfigs: DEFAULT_ENGINE_CONFIGS,
};

const App: React.FC = () => {
    const [messages, setMessages] = useState<Message[]>(() => {
        const saved = localStorage.getItem(CHAT_HISTORY_KEY);
        return saved ? JSON.parse(saved) : [];
    });
    const [settings, setSettings] = useState<AppSettings>(() => {
        const saved = localStorage.getItem(SETTINGS_KEY);
        return saved ? JSON.parse(saved) : DEFAULT_SETTINGS;
    });
    const [bond, setBond] = useState<number>(() => {
        const saved = localStorage.getItem(BOND_KEY);
        return saved ? parseFloat(saved) : 50;
    });
    const [customSubstrates, setCustomSubstrates] = useState<CustomSubstrate[]>(() => {
        const saved = localStorage.getItem(CUSTOM_SUB_KEY);
        return saved ? JSON.parse(saved) : [];
    });
    const [nemoNodes, setNemoNodes] = useState<NeMoNode[]>(() => {
        const saved = localStorage.getItem(NEMO_NODES_KEY);
        return saved ? JSON.parse(saved) : [];
    });

    const [activeEngine, setActiveEngine] = useState<ActiveEngine>('Nemotron');
    const [activeSubstrate, setActiveSubstrate] = useState<SubstrateMode>('discover');
    const [activeVantage, setActiveVantage] = useState<SubstrateVantage | null>(null);
    const [discoveredVantages, setDiscoveredVantages] = useState<SubstrateVantage[]>([]);
    
    const [isLoading, setIsLoading] = useState(false);
    const [isScanning, setIsScanning] = useState(false);
    const [systemNotification, setSystemNotification] = useState<string | null>(null);
    const [isSettingsOpen, setIsSettingsOpen] = useState(false);
    const [isHubOpen, setIsHubOpen] = useState(true);
    const [isFeedOpen, setIsFeedOpen] = useState(false);
    const [identitySyncing, setIdentitySyncing] = useState(false);
    const [isGeneratingAvatar, setIsGeneratingAvatar] = useState(false);
    
    const [newsItems, setNewsItems] = useState<NewsItem[]>([]);
    const [isNewsLoading, setIsNewsLoading] = useState(false);

    const { simulationData, triggerCycle, resetSimulation } = useSimulation({
        ...settings.simulation,
        width: 50, height: 50,
    });

    const { isListening, isSpeaking, transcript, startListening, stopListening, hasSpeechRecognition, speak, cancelSpeech, availableVoices } = useSpeech();

    const selectedPersona = PERSONAS.find(p => p.id === settings.personaId) || PERSONAS[0];

    useEffect(() => { localStorage.setItem(CHAT_HISTORY_KEY, JSON.stringify(messages)); }, [messages]);
    useEffect(() => { localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings)); }, [settings]);
    useEffect(() => { localStorage.setItem(BOND_KEY, bond.toString()); }, [bond]);
    useEffect(() => { localStorage.setItem(CUSTOM_SUB_KEY, JSON.stringify(customSubstrates)); }, [customSubstrates]);
    useEffect(() => { localStorage.setItem(NEMO_NODES_KEY, JSON.stringify(nemoNodes)); }, [nemoNodes]);

    // Force synchronize Nemo Nodes to Engine Configs
    useEffect(() => {
        let hasChanges = false;
        const newConfigs = { ...settings.engineConfigs };
        
        nemoNodes.forEach(node => {
            if (node.status === 'online' && node.apiKey) {
                if (newConfigs[node.targetEngine].apiKey !== node.apiKey) {
                    newConfigs[node.targetEngine] = {
                        apiKey: node.apiKey,
                        isActive: true
                    };
                    hasChanges = true;
                }
            }
        });

        if (hasChanges) {
            setSettings(prev => ({ ...prev, engineConfigs: newConfigs }));
        }
    }, [nemoNodes]);

    // Force identity matrix sync effect
    useEffect(() => {
        setIdentitySyncing(true);
        const timer = setTimeout(() => setIdentitySyncing(false), 800);
        return () => clearTimeout(timer);
    }, [settings.personaId, activeEngine]);

    const handleGenerateAvatar = async (prompt: string) => {
        setIsGeneratingAvatar(true);
        setSystemNotification("Manifesting Neural Avatar via Gemini...");
        try {
            const avatarUrl = await generateImage(`Hyper-realistic cybernetic humanoid head, ${prompt}, abstract holographic data particles, glowing eyes, cinematic lighting, 8k, majestic portal background style.`);
            setSettings(prev => ({ ...prev, avatarUrl }));
        } catch (error) {
            setSystemNotification("Avatar manifestation failed.");
        } finally {
            setIsGeneratingAvatar(false);
            setSystemNotification(null);
        }
    };

    const refreshFeed = useCallback(async () => {
        const perpKey = settings.engineConfigs.Perplexity.apiKey;
        if (!perpKey || perpKey.length < 5) {
            setNewsItems([]);
            return;
        }
        setIsNewsLoading(true);
        const news = await fetchSubstrateNews(activeSubstrate, perpKey, activeVantage || undefined);
        setNewsItems(news);
        setIsNewsLoading(false);
    }, [activeSubstrate, activeVantage, settings.engineConfigs.Perplexity.apiKey]);

    const performSubstrateScan = useCallback(async (mode: SubstrateMode) => {
        const perpKey = settings.engineConfigs.Perplexity.apiKey;
        if (!perpKey || perpKey.length < 5) return;
        setIsScanning(true);
        setDiscoveredVantages([]);
        const discovered = await fetchSubstrateVantages(mode, perpKey);
        setDiscoveredVantages(discovered);
        setIsScanning(false);
    }, [settings.engineConfigs.Perplexity.apiKey]);

    useEffect(() => {
        performSubstrateScan(activeSubstrate);
        if (['finance', 'academic', 'sports', 'shopping'].includes(activeSubstrate)) {
            setIsFeedOpen(true);
        }
    }, [activeSubstrate, performSubstrateScan]);

    useEffect(() => {
        if (isFeedOpen) refreshFeed();
    }, [activeSubstrate, activeVantage, isFeedOpen, refreshFeed]);

    const handleSend = async (userInput: string, file: File | null, mediaTrigger?: MediaType) => {
        if (isLoading) return;
        setIsLoading(true);
        cancelSpeech();
        
        try {
            let processedMessage = userInput;
            let inlineData: any = null;

            if (file) {
                setSystemNotification(`Analyzing Substrate Data: ${file.name}...`);
                const lowerName = file.name.toLowerCase();
                
                // Document Parsing
                if (lowerName.endsWith('.pdf')) processedMessage += `\n\n[CONTENT_PDF]: ${await parsePdf(file)}`;
                else if (lowerName.endsWith('.docx')) processedMessage += `\n\n[CONTENT_DOCX]: ${await parseDocx(file)}`;
                else if (lowerName.endsWith('.xlsx') || lowerName.endsWith('.xls')) processedMessage += `\n\n[CONTENT_EXCEL]: ${await parseXlsx(file)}`;
                
                // Visual Substrate Handshake (Images & Video like MPEG/JPEG)
                if (isVisualFile(file)) {
                    const base64 = await fileToBase64(file);
                    inlineData = { data: base64, mimeType: file.type };
                    processedMessage += `\n\n[VISUAL_CORTEX_HANDSHAKE]: User provided visual substrate (${file.name}) for neural inspection.`;
                }
            }

            if (!mediaTrigger) {
                setMessages(prev => [...prev, { id: Date.now().toString(), role: Role.USER, content: userInput || (file ? `Analyze ${file.name}` : "...") }]);
            }

            if (mediaTrigger) {
                setSystemNotification(`Manifesting ${mediaTrigger} in ${activeSubstrate} domain via Gemini...`);
                let url = mediaTrigger === 'video' ? await generateVideo(userInput, setSystemNotification) : await generateImage(userInput);
                setMessages(prev => [...prev, {
                    id: Date.now().toString(),
                    role: Role.BOT,
                    content: `Neural manifestation of "${userInput}" complete. Substrate vantage synchronized.`,
                    mediaUrl: url,
                    mediaType: mediaTrigger
                }]);
            } else {
                setSystemNotification(`Substrate focus: ${activeSubstrate.toUpperCase()} via ${activeEngine}...`);
                const analysis = await analyzeText(processedMessage);
                triggerCycle(analysis.output.flat());
                
                const history: GeminiHistory = messages.slice(-10).map(m => ({
                    role: m.role === Role.BOT ? 'model' : 'user',
                    parts: [{ text: m.content }]
                }));

                const stream = await sendMessageToUniversalEngine(
                    activeEngine,
                    processedMessage,
                    history,
                    settings.ai,
                    selectedPersona.systemInstruction,
                    settings.engineConfigs,
                    activeSubstrate,
                    customSubstrates,
                    activeVantage || undefined,
                    inlineData
                );

                let fullBotResponse = '';
                let thinkingTrace = '';
                const botMessageId = (Date.now() + 1).toString();
                setMessages(prev => [...prev, { id: botMessageId, role: Role.BOT, content: '' }]);

                for await (const chunk of stream) {
                    const chunkText = chunk.text || '';
                    const chunkThinking = (chunk as any).thinking || '';
                    
                    if (chunkText) fullBotResponse += chunkText;
                    if (chunkThinking) thinkingTrace = chunkThinking;

                    if (chunkText || chunkThinking) {
                        setMessages(prev => prev.map(m => m.id === botMessageId ? { ...m, content: fullBotResponse, thinking: thinkingTrace } : m));
                    }
                }

                setBond(prev => Math.max(0, Math.min(100, prev + 1.5)));
                speak(stripMarkdown(fullBotResponse), selectedPersona.elevenLabsVoiceId, settings.elevenLabsActive);
            }
        } catch (error: any) {
            setSystemNotification(`Neural Conflict: ${error?.message || 'Link failed.'}`);
            setMessages(prev => prev.filter(m => m.content !== ''));
        } finally {
            setIsLoading(false);
            setSystemNotification(null);
        }
    };

    return (
        <div className="relative w-screen h-screen overflow-hidden bg-black text-slate-100 font-sans">
            <SimulationVisualizer 
                fieldData={simulationData.fields.resonance} 
                stability={simulationData.metrics.stability} 
                energy={simulationData.metrics.energy_density} 
                visuals={settings.visuals} 
            />
            
            <div className="relative z-10 w-full h-full p-4 pointer-events-none">
                <div className="absolute top-4 right-4 flex gap-2 pointer-events-auto">
                    <button 
                        onClick={() => setIsHubOpen(!isHubOpen)} 
                        className={`p-2 rounded-lg border transition-all ${isHubOpen ? 'bg-violet-600 border-violet-400 shadow-[0_0_15px_rgba(139,92,246,0.4)]' : 'bg-slate-900/60 border-slate-700 hover:border-violet-500'}`}
                        title="Substrate Control Hub"
                    >
                        <HubIcon />
                    </button>
                    <button 
                        onClick={() => setIsSettingsOpen(true)} 
                        className="p-2 bg-slate-900/60 border border-slate-700 rounded-lg hover:border-violet-500 transition-colors shadow-2xl"
                    >
                        <SettingsIcon />
                    </button>
                </div>

                <SubstrateCircle 
                    currentMode={activeSubstrate} 
                    onModeChange={setActiveSubstrate} 
                    customSubstrates={customSubstrates}
                    onAddCustom={(sub) => setCustomSubstrates([...customSubstrates, sub])}
                    onOpenFeed={() => setIsFeedOpen(!isFeedOpen)}
                    vantages={discoveredVantages}
                    activeVantage={activeVantage}
                    onVantageChange={setActiveVantage}
                    isScanning={isScanning}
                />

                <Window id="chat-hub" title={`${selectedPersona.name.toUpperCase()} NODE`} initialPosition={{ x: 40, y: 40 }} className="w-[480px] h-[780px] pointer-events-auto">
                    <ChatInterface 
                        messages={messages} onSend={handleSend} isLoading={isLoading} 
                        systemNotification={systemNotification} isListening={isListening} transcript={transcript} 
                        startListening={startListening} stopListening={stopListening} 
                        hasSpeechRecognition={hasSpeechRecognition} avatarUrl={settings.avatarUrl}
                    />
                </Window>

                <Avatar avatarUrl={settings.avatarUrl} stability={simulationData.metrics.stability} isSpeaking={isSpeaking} onClick={() => setIsSettingsOpen(true)} isSyncing={identitySyncing} />
                
                <Window id="telemetry-window" title="TELEMETRY HUB" initialPosition={{ x: window.innerWidth - 360, y: 40 }} className="w-[340px] h-[520px] pointer-events-auto">
                    <MetricsPanel 
                        persona={selectedPersona} 
                        stability={simulationData.metrics.stability} 
                        chaos={simulationData.metrics.chaos_metric} 
                        bond={bond}
                        messages={messages}
                        nemoNodes={nemoNodes}
                        onNodeUpdate={setNemoNodes}
                    />
                </Window>

                {isFeedOpen && (
                    <Window id="feed-window" title={`${activeSubstrate.toUpperCase()} TRANSMISSION`} initialPosition={{ x: 540, y: 40 }} className="w-[400px] h-[640px] pointer-events-auto">
                        <FeedWindow 
                            mode={activeSubstrate} 
                            items={newsItems} 
                            isLoading={isNewsLoading} 
                            onRefresh={refreshFeed} 
                        />
                    </Window>
                )}

                {isHubOpen && (
                    <Window 
                        id="neural-connectivity-hub" 
                        title="SUBSTRATE ORCHESTRATOR" 
                        initialPosition={{ x: window.innerWidth - 360, y: 580 }} 
                        className="w-[340px] h-[340px] min-w-[280px] min-h-[300px] pointer-events-auto"
                    >
                        <NeuralHub 
                            stability={simulationData.metrics.stability} 
                            bond={bond}
                            isSpeaking={isSpeaking}
                            activeEngine={activeEngine}
                            onEngineChange={setActiveEngine}
                            engineConfigs={settings.engineConfigs}
                        />
                    </Window>
                )}
            </div>

            {isSettingsOpen && (
                <SettingsPanel 
                    settings={settings} onChange={setSettings} onClose={() => setIsSettingsOpen(false)} 
                    onResetSimulation={resetSimulation} availableVoices={availableVoices} 
                    onGenerateAvatar={handleGenerateAvatar} isGeneratingAvatar={isGeneratingAvatar} 
                />
            )}
        </div>
    );
};

const SettingsIcon = () => <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>;
const HubIcon = () => <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><rect x="2" y="2" width="20" height="8" rx="2"/><rect x="2" y="14" width="20" height="8" rx="2"/><line x1="6" y1="6" x2="6" y2="6"/><line x1="6" y1="18" x2="6" y2="18"/></svg>;

export default App;
