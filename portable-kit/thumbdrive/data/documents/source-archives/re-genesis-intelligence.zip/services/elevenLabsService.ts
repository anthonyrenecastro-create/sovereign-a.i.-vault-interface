
const ELEVEN_LABS_API_KEY = 'b4dc5ad8147543de7f8d86620ce23de8900d4c435bced97027f13dca5668b296';
const BASE_URL = 'https://api.elevenlabs.io/v1';

/**
 * Extracts a readable error message from an ElevenLabs API response.
 */
const getErrorMessage = async (response: Response): Promise<string> => {
    try {
        const errorData = await response.json();
        if (errorData.detail) {
            if (typeof errorData.detail === 'string') return errorData.detail;
            if (typeof errorData.detail === 'object') {
                return errorData.detail.message || errorData.detail.status || JSON.stringify(errorData.detail);
            }
        }
        if (errorData.message) return errorData.message;
        return JSON.stringify(errorData);
    } catch (e) {
        return response.statusText || 'Unknown network error';
    }
};

/**
 * Converts text to speech using ElevenLabs API.
 */
export const textToSpeech = async (text: string, voiceId: string, stability: number = 0.5): Promise<HTMLAudioElement> => {
    try {
        const response = await fetch(`${BASE_URL}/text-to-speech/${voiceId}`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'xi-api-key': ELEVEN_LABS_API_KEY,
            },
            body: JSON.stringify({
                text: text,
                model_id: 'eleven_multilingual_v2',
                voice_settings: {
                    stability: stability,
                    similarity_boost: 0.8,
                },
            }),
        });

        if (!response.ok) {
            const message = await getErrorMessage(response);
            throw new Error(`ElevenLabs TTS failed: ${message}`);
        }

        const blob = await response.blob();
        return new Audio(URL.createObjectURL(blob));
    } catch (error: any) {
        console.error('Error in ElevenLabs TTS:', error);
        throw error;
    }
};

/**
 * Generates a sound effect from a text prompt.
 */
export const generateSoundEffect = async (text: string): Promise<HTMLAudioElement> => {
    try {
        const response = await fetch(`${BASE_URL}/sound-generation`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'xi-api-key': ELEVEN_LABS_API_KEY,
            },
            body: JSON.stringify({
                text: text,
                duration_seconds: 5,
                prompt_influence: 0.3
            }),
        });

        if (!response.ok) {
            const message = await getErrorMessage(response);
            throw new Error(`Sound generation failed: ${message}`);
        }

        const blob = await response.blob();
        return new Audio(URL.createObjectURL(blob));
    } catch (error: any) {
        console.error('Error generating sound effect:', error);
        throw error;
    }
};
