
import { GoogleGenAI } from "@google/genai";
import type { GeminiHistory, AiSettings, ActiveEngine } from '../types';
import type { Content } from '@google/genai';

/**
 * Sends a message to the Gemini model with enhanced context awareness for active connections.
 */
export const sendMessageToBot = async (
    message: string, 
    history: GeminiHistory, 
    settings: AiSettings, 
    systemInstruction: string,
    activeEngine: ActiveEngine,
    connectedSources: string[]
) => {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

    const connectivityContext = connectedSources.length > 0 
        ? `\n\nCURRENT CONNECTED SUBSTRATES: [${connectedSources.join(', ')}]. \nAs the agent, you now have neural links to these data sources. Reference them if the user asks for analysis.`
        : "\n\nNO EXTERNAL SUBSTRATES CONNECTED.";

    const engineContext = `\nPOWERING ENGINE: ${activeEngine}.`;

    const contents: Content[] = [
        ...history,
        { role: 'user', parts: [{ text: message }] }
    ];

    try {
        const modelName = 'gemini-3-flash-preview';

        const response = await ai.models.generateContentStream({
            model: modelName,
            contents: contents,
            config: {
                systemInstruction: `${systemInstruction}${connectivityContext}${engineContext}\n\nSTRICT: ONLY natural language.`,
                temperature: settings.temperature,
                maxOutputTokens: settings.maxOutputTokens,
            },
        });
        return response;
    } catch (error: any) {
        console.error("Model stream error:", error);
        throw error;
    }
};

export const generateImage = async (prompt: string): Promise<string> => {
    // Re-initialize to ensure latest API key is used
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    try {
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash-image',
            contents: { 
                parts: [{ 
                    text: `A cinematic, hyper-realistic 3D render of a cybernetic avatar head. ${prompt}. High-detail, holographic elements, cinematic lighting, majestic portal background.` 
                }] 
            },
            config: { 
                imageConfig: { 
                    aspectRatio: "1:1" 
                } 
            },
        });

        // Robust part extraction as per guidelines
        if (response.candidates && response.candidates[0].content.parts) {
            for (const part of response.candidates[0].content.parts) {
                if (part.inlineData) {
                    const base64Data = part.inlineData.data;
                    return `data:image/png;base64,${base64Data}`;
                }
            }
        }
        
        throw new Error("No inline image data found in response parts.");
    } catch (error: any) {
        console.error("Image generation failed:", error);
        throw error;
    }
};

export const generateVideo = async (prompt: string, onProgress?: (msg: string) => void): Promise<string> => {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    if (onProgress) onProgress("Initializing Veo Substrate...");
    try {
        let operation = await ai.models.generateVideos({
            model: 'veo-3.1-fast-generate-preview',
            prompt: prompt,
            config: {
                numberOfVideos: 1,
                resolution: '720p',
                aspectRatio: '16:9'
            }
        });

        const maxWait = 30;
        let count = 0;
        while (!operation.done && count < maxWait) {
            count++;
            if (onProgress) onProgress(`Coalescing Video... (${count}/${maxWait})`);
            await new Promise(resolve => setTimeout(resolve, 10000));
            operation = await ai.operations.getVideosOperation({ operation: operation });
        }
        if (!operation.done) throw new Error("Video manifestation timed out.");
        const downloadLink = operation.response?.generatedVideos?.[0]?.video?.uri;
        if (!downloadLink) throw new Error("Video manifestation failed - no URI.");
        if (onProgress) onProgress("Retrieving bytes...");
        const response = await fetch(`${downloadLink}&key=${process.env.API_KEY}`);
        const blob = await response.blob();
        return URL.createObjectURL(blob);
    } catch (error: any) {
        console.error("Video generation error:", error);
        throw error;
    }
};
