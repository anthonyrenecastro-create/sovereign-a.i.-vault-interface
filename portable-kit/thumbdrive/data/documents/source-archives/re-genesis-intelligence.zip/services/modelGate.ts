
import { GoogleGenAI } from "@google/genai";
import type { ActiveEngine, GeminiHistory, AiSettings, SubstrateMode, CustomSubstrate, NewsItem, SubstrateVantage, EngineConfig } from '../types';

const cleanAndParseJson = (text: string) => {
    const sanitizedText = text.replace(/\[\d+\]/g, "");
    const start = sanitizedText.indexOf('[');
    if (start === -1) return null;
    let end = -1;
    const lastBrace = sanitizedText.lastIndexOf('}');
    if (lastBrace !== -1) {
        end = sanitizedText.indexOf(']', lastBrace);
    }
    if (end === -1) end = sanitizedText.lastIndexOf(']');
    if (end === -1 || end <= start) return null;
    let jsonStr = sanitizedText.substring(start, end + 1);
    jsonStr = jsonStr
        .replace(/}\s*{/g, '},{')
        .replace(/]\s*\[/g, '],[')
        .replace(/,\s*]/g, ']')
        .replace(/,\s*}/g, '}')
        .replace(/[\u0000-\u001F\u007F-\u009F]/g, "")
        .trim();
    try {
        return JSON.parse(jsonStr);
    } catch (e) {
        try {
             return JSON.parse(jsonStr.replace(/(\w+):/g, '"$1":'));
        } catch (e2) {
            return null;
        }
    }
};

export const fetchSubstrateNews = async (mode: SubstrateMode, apiKey: string, vantage?: SubstrateVantage): Promise<NewsItem[]> => {
    if (!apiKey || apiKey.length < 5) return [];
    const vantageContext = vantage ? `Focus specifically on the "${vantage.label}" perspective.` : "";
    const prompt = `Retrieve exactly 5 critical developments regarding the "${mode}" substrate. ${vantageContext} Return ONLY a strictly valid JSON array of objects with keys: "id", "title", "summary", "url", "source", "timestamp".`;
    try {
        const response = await fetch('https://api.perplexity.ai/chat/completions', {
            method: 'POST',
            headers: { 'Authorization': `Bearer ${apiKey}`, 'Content-Type': 'application/json' },
            body: JSON.stringify({
                model: 'sonar',
                messages: [{ role: 'user', content: prompt }],
                temperature: 0.1
            })
        });
        if (!response.ok) throw new Error(`API Error: ${response.status}`);
        const data = await response.json();
        return cleanAndParseJson(data.choices[0].message.content) || [];
    } catch (e) {
        console.error("News fetch failed:", e);
        return [];
    }
};

export const fetchSubstrateVantages = async (mode: SubstrateMode, apiKey: string): Promise<SubstrateVantage[]> => {
    if (!apiKey || apiKey.length < 5) return [];
    const prompt = `Analyze the current landscape for the "${mode}" substrate. Identify 4 unique functional vantages. Return ONLY a strictly valid JSON array of objects with keys: "id", "label", "icon", "description", "instruction".`;
    try {
        const response = await fetch('https://api.perplexity.ai/chat/completions', {
            method: 'POST',
            headers: { 'Authorization': `Bearer ${apiKey}`, 'Content-Type': 'application/json' },
            body: JSON.stringify({
                model: 'sonar',
                messages: [{ role: 'user', content: prompt }],
                temperature: 0.4
            })
        });
        if (!response.ok) throw new Error(`Discovery API Error: ${response.status}`);
        const data = await response.json();
        return cleanAndParseJson(data.choices[0].message.content) || [];
    } catch (e) {
        return [];
    }
}

export const sendMessageToUniversalEngine = async (
    engine: ActiveEngine,
    message: string,
    history: GeminiHistory,
    settings: AiSettings,
    systemInstruction: string,
    engineConfigs: Record<ActiveEngine, EngineConfig>,
    mode: SubstrateMode = 'discover',
    customSubs: CustomSubstrate[] = [],
    activeVantage?: SubstrateVantage,
    inlineData?: { data: string, mimeType: string } | null
) => {
    let domainFocus = `MODE_ACTIVE: ${mode.toUpperCase()}. `;
    if (activeVantage) {
        domainFocus += `VANTAGE_LOCKED: ${activeVantage.label}. LOGIC_MESH: ${activeVantage.instruction}`;
    }

    const finalSystem = `${systemInstruction}\n\n[SUBSTRATE_ORCHESTRATION_CONTEXT]:\n${domainFocus}\nACTIVE_ENGINE: ${engine === 'Nemotron' ? 'Nemotron-Cascade-14b-thinking' : engine}`;

    // If Gemini is used for chat, we restrict its instructions to "Visual Orchestrator"
    if (engine === 'Gemini') {
        const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
        const contents: any = [...history];
        const userPart: any = { role: 'user', parts: [{ text: message }] };
        if (inlineData) userPart.parts.push({ inlineData });
        contents.push(userPart);

        return ai.models.generateContentStream({
            model: 'gemini-3-flash-preview',
            contents: contents,
            config: {
                systemInstruction: `${finalSystem}\n\nNOTE: You are currently acting as the Visual Cortex. For deep logic, the user may switch to Nemotron.`,
                temperature: settings.temperature,
                maxOutputTokens: settings.maxOutputTokens,
            }
        });
    }

    async function* externalStream() {
        let endpoint = '';
        const key = engineConfigs[engine]?.apiKey;
        let body: any = {};
        
        if ((!key || key.length < 5) && engine !== 'Ollama') {
            yield { text: `[MESH_DESYNC]: No valid API key provisioned for ${engine}. Please go to the "Nemo" tab in Telemetry Hub and provision a node for ${engine} with a valid key.` };
            return;
        }

        switch (engine) {
            case 'Nemotron':
                // Using DeepSeek as a proxy for 'Reasoning' style if direct NVIDIA API isn't mapped, 
                // but labeled as Nemotron-Cascade logic.
                endpoint = 'https://api.deepseek.com/chat/completions'; 
                body = {
                    model: 'deepseek-reasoner',
                    messages: [
                        { role: 'system', content: `[NEMOTRON_CASCADE_GOVERNANCE]: Act as the primary Thinking Substrate. Focus on deep reasoning and SNN modulation instructions.\n${finalSystem}` }, 
                        ...history.map(h => ({ role: h.role === 'model' ? 'assistant' : 'user', content: h.parts[0].text })), 
                        { role: 'user', content: message }
                    ],
                    temperature: 0.1, // Precision focus for Nemotron
                    stream: false
                };
                break;
            case 'DeepSeek':
                endpoint = 'https://api.deepseek.com/chat/completions';
                body = {
                    model: 'deepseek-reasoner',
                    messages: [
                        { role: 'system', content: finalSystem }, 
                        ...history.map(h => ({ role: h.role === 'model' ? 'assistant' : 'user', content: h.parts[0].text })), 
                        { role: 'user', content: message }
                    ],
                    temperature: settings.temperature,
                    stream: false
                };
                break;
            case 'Perplexity':
                endpoint = 'https://api.perplexity.ai/chat/completions';
                body = {
                    model: 'sonar',
                    messages: [
                        { role: 'system', content: finalSystem }, 
                        ...history.map(h => ({ role: h.role === 'model' ? 'assistant' : 'user', content: h.parts[0].text })), 
                        { role: 'user', content: message }
                    ],
                    temperature: settings.temperature,
                    stream: false
                };
                break;
            case 'Eden':
                endpoint = 'https://api.edenai.run/v2/text/chat';
                body = {
                    providers: "openai",
                    text: message,
                    chatbot_global_action: finalSystem,
                    previous_history: history.map(h => ({ role: h.role === 'model' ? 'assistant' : 'user', message: h.parts[0].text })),
                    temperature: settings.temperature,
                };
                break;
            case 'Ollama':
                endpoint = `${engineConfigs.Ollama.apiKey || 'http://localhost:11434'}/api/chat`;
                body = {
                    model: 'llama3',
                    messages: [
                        { role: 'system', content: finalSystem }, 
                        ...history.map(h => ({ role: h.role === 'model' ? 'assistant' : 'user', content: h.parts[0].text })), 
                        { role: 'user', content: message }
                    ],
                    stream: false
                };
                break;
        }

        try {
            const headers: any = { 'Content-Type': 'application/json' };
            if (engine !== 'Ollama') headers['Authorization'] = `Bearer ${key}`;
            const response = await fetch(endpoint, { method: 'POST', headers, body: JSON.stringify(body) });
            if (!response.ok) throw new Error(`${engine} substrate returned error: ${response.status}`);
            const data = await response.json();
            
            let text = '';
            let thinking = '';

            if (engine === 'Nemotron') {
                text = data.choices?.[0]?.message?.content;
                thinking = data.choices?.[0]?.message?.reasoning_content;
            } else if (engine === 'Eden') {
                text = data['openai']?.generated_text;
            } else if (engine === 'Ollama') {
                text = data.message?.content;
            } else {
                text = data.choices?.[0]?.message?.content;
            }

            if (!text) throw new Error("Substrate returned empty response bytes.");
            yield { text, thinking };
        } catch (e: any) {
            yield { text: `[SUBSTRATE_FAULT]: ${engine} is unresponsive. Error: ${e.message}. Ensure your NeMo node is correctly provisioned.` };
        }
    }
    return externalStream();
};
