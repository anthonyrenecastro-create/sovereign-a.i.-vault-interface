// Consolidated into services/geminiService.ts
export * from './services/geminiService';
