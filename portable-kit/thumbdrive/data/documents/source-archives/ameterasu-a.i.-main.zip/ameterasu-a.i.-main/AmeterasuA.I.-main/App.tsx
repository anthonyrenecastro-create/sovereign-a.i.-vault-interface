import React, { useState, useEffect, useCallback, useRef } from 'react';
import { useSimulation } from './hooks/useSimulation';
import { useSpeech } from './hooks/useSpeech';
import { useThreads } from './hooks/useThreads';
import { sendMessageToBot } from './services/geminiService';
import simulationService from './services/simulationService';
import type { Message, SimulationOutput, GeminiHistory, AppSettings } from './types';
import { Role } from './types';
import { CHAT_HISTORY_KEY, SIMULATION_STATE_KEY, SETTINGS_KEY, THREADS_KEY, CURRENT_THREAD_KEY } from './constants';
import { parsePdf, parseDocx } from './utils/fileParser';
import { stripMarkdown } from './utils/textUtils';

import Header from './components/Header';
import ChatInterface from './components/ChatInterface';
import SimulationVisualizer from './components/SimulationVisualizer';
import SettingsPanel from './components/SettingsPanel';
import ThreadsPanel from './components/ThreadsPanel';
import MetricsDashboard from './components/MetricsDashboard';
import { stepHRM } from './backend/services/interpreterService';
const textToNumericArray = (text: string, length: number = 50): number[] => {
    const arr = new Array(length).fill(0);
    if (!text) return arr;
    for (let i = 0; i < text.length; i++) {
        arr[i % length] += text.charCodeAt(i) / 255.0;
    }
    const maxVal = Math.max(...arr.map(v => Math.abs(v)));
    if (maxVal === 0) return arr;
    return arr.map(v => (v / maxVal) * 0.1);
};

const formatSystemReport = (result: SimulationOutput): string => {
  if (!result || result.error) return "[SYSTEM STATE REPORT]\nError in simulation cycle.";

const formatSystemReport = (result: SimulationOutput): string => {
  if (!result || result.error) {
    return "[SYSTEM STATE REPORT]\nError in simulation cycle.\n[/SYSTEM STATE REPORT]";
  }

  return `[SYSTEM STATE REPORT]
Time: ${result.time.toFixed(2)}
Theta: ${result.hrm.theta.toFixed(4)}
Active Channel: ${result.hrm.activeChannel}
Active Domain: ${result.hrm.activeDomain}
Active Layer: ${result.hrm.activeLayer}
Stability: ${result.stability.toFixed(4)}
Global Coherence: ${result.hrm.globalCoherence.toFixed(4)}
Fractal Score: ${result.hrm.fractalScore.toFixed(4)}
Precision Score: ${result.hrm.precisionScore.toFixed(4)}
Optimization Score: ${result.hrm.optimizationScore.toFixed(4)}
Chaos: ${result.patterns.chaos_metric.toFixed(4)}
MI Loss: ${result.mi_feedback.mi_loss.toFixed(5)}
[/SYSTEM STATE REPORT]`;
};

    // ✅ STEP 1: Call HRM safely
    try {
        const hrmState = stepHRMuserMessageContent

        const systemReport = `[SYSTEM STATE REPORT]
Time: ${hrmState.time}
Theta: ${hrmState.theta.toFixed(4)}
Active Channel: ${hrmState.activeChannel}
Active Domain: ${hrmState.activeDomain}
Active Layer: ${hrmState.activeLayer}
Stability: ${hrmState.stability.toFixed(4)}
Global Coherence: ${hrmState.global_coherence.toFixed(4)}
Fractal Score: ${hrmState.fractal_score.toFixed(4)}
Precision Score: ${hrmState.precision_score.toFixed(4)}
Optimization Score: ${hrmState.optimization_score.toFixed(4)}
[/SYSTEM STATE REPORT]`;

    } catch (err) {
        console.error("HRM error:", err);
    }
    if (!result || result.error) return "[SYSTEM STATE REPORT]\nError in simulation cycle.";
    return `[SYSTEM STATE REPORT]
Time: ${result.time.toFixed(2)} | Stability: ${result.stability.toFixed(4)} | Chaos: ${result.patterns.chaos_metric.toFixed(4)} | MI Loss: ${result.mi_feedback.mi_loss.toFixed(5)}
[/SYSTEM STATE REPORT]`;
};

const transformToGeminiHistory = (messages: Message[]): GeminiHistory => {
  return messages
    .filter(msg => msg.content.trim() !== '')
    .map(msg => ({
        role: msg.role,
        parts: [{ text: msg.content }],
    }));
};

const defaultSettings: AppSettings = {
    ai: {
        temperature: 0.7,
        maxOutputTokens: 1024,
    },
    simulation: {
        syntropyTarget: 0.5,
        initialMass: 1.0,
        initialCoupling: 0.1,
    },
    theme: {
        theme: 'dark',
    }
};

const loadSettings = (): AppSettings => {
    try {
        const savedSettings = localStorage.getItem(SETTINGS_KEY);
        if (savedSettings) {
            const parsed = JSON.parse(savedSettings);
            // Merge with defaults to ensure all keys are present
            return {
                ai: { ...defaultSettings.ai, ...parsed.ai },
                simulation: { ...defaultSettings.simulation, ...parsed.simulation },
                theme: { ...defaultSettings.theme, ...parsed.theme },
            };
        }
    } catch (error) {
        console.error("Failed to load settings:", error);
    }
    return defaultSettings;
};


export default function App(): React.ReactNode {
    const [settings, setSettings] = useState<AppSettings>(loadSettings);
    const [isSettingsOpen, setIsSettingsOpen] = useState(false);
    const [isThreadsOpen, setIsThreadsOpen] = useState(false);
    
    const {
        threads,
        currentThreadId,
        currentThread,
        createThread,
        switchThread,
        updateThread,
        addMessageToCurrentThread,
        updateCurrentThreadSimulationState,
        deleteThread,
    } = useThreads();

    const { triggerCycle, resetSimulation, startSimulation, stopSimulation, simulationSpeed, setSimulationSpeed } = useSimulation({
        ...settings.simulation,
        width: 50,
        height: 50,
    });
    const { isListening, transcript, startListening, stopListening, hasSpeechRecognition, speak, cancelSpeech } = useSpeech();
    
    const [isLoading, setIsLoading] = useState(false);
    const [systemNotification, setSystemNotification] = useState<string | null>(null);
    const hasInitialized = useRef(false);

    useEffect(() => {
        // Handle migration from old single-thread storage to new thread-based storage
        const savedHistoryJson = localStorage.getItem(CHAT_HISTORY_KEY);
        const savedSimStateJson = localStorage.getItem(SIMULATION_STATE_KEY);

        if (savedHistoryJson && threads.length === 0) {
            try {
                const parsedHistory = JSON.parse(savedHistoryJson) as Message[];
                if (Array.isArray(parsedHistory) && parsedHistory.length > 0) {
                    // Create initial thread from old data
                    const initialThread = {
                        id: 'migrated-thread',
                        name: 'Main Conversation',
                        messages: parsedHistory,
                        simulationState: {} as any,
                        createdAt: Date.now(),
                        updatedAt: Date.now(),
                    };
                    
                    // Load simulation state if available
                    if (savedSimStateJson) {
                        try {
                            initialThread.simulationState = JSON.parse(savedSimStateJson);
                            simulationService.loadState(initialThread.simulationState);
                        } catch (error) {
                            console.error("Failed to load simulation state:", error);
                        }
                    }
                    
                    // This will be handled by useThreads, but we need to set it manually for migration
                    localStorage.setItem(THREADS_KEY, JSON.stringify([initialThread]));
                    localStorage.setItem(CURRENT_THREAD_KEY, initialThread.id);
                    
                    setSystemNotification("Continuity established. Cognitive state restored.");
                    setTimeout(() => setSystemNotification(null), 4000);
                }
            } catch (error) {
                console.error("Failed to migrate chat history:", error);
                localStorage.removeItem(CHAT_HISTORY_KEY);
                localStorage.removeItem(SIMULATION_STATE_KEY);
            }
        }

        hasInitialized.current = true;
    }, [threads.length]);



    const handleSend = useCallback(async (userInput: string, file: File | null) => {
        if (!currentThread) return;

        // Slow down the simulation before triggering a cycle
        const prevSpeed = simulationSpeed;
        setSimulationSpeed(0.2); // Slow mode (5x slower)

        const userMessageContent = userInput.trim();
        if ((userMessageContent === '' && !file) || isLoading) return;

        setIsLoading(true);
        cancelSpeech();

        let messageWithFileContext = userMessageContent;
        let uiMessageContent = userMessageContent;

        if (file) {
            try {
                const parsedText =
                    file.type === 'application/pdf'
                        ? await parsePdf(file)
                        : await parseDocx(file);

                messageWithFileContext = `[START OF DOCUMENT: ${file.name}]\n\n${parsedText}\n\n[END OF DOCUMENT]\n\nUser query: "${userMessageContent}"`;
                uiMessageContent = `[File: ${file.name}]\n${userMessageContent}`;
            } catch (parseError: any) {
                const errorMessage = parseError.message || 'Unknown error';
                addMessageToCurrentThread({
                    role: Role.BOT,
                    content: `I couldn't read the file. Error: ${errorMessage}`,
                });
                setIsLoading(false);
                setSimulationSpeed(prevSpeed);
                return;
            }
        }

        addMessageToCurrentThread({ role: Role.USER, content: uiMessageContent });

        const currentHistory = transformToGeminiHistory([
            ...currentThread.messages,
            { id: crypto.randomUUID(), role: Role.USER, content: uiMessageContent },
        ]);

        let hrmReport = '';

        try {
            const hrmState = await stepHRM(userMessageContent, currentThread.id);

            hrmReport = `[HRM SYSTEM STATE REPORT]\nTime: ${hrmState.time}\nTheta: ${hrmState.theta.toFixed(4)}\nActive Channel: ${hrmState.activeChannel}\nActive Domain: ${hrmState.activeDomain}\nActive Layer: ${hrmState.activeLayer}\nStability: ${hrmState.stability.toFixed(4)}\nGlobal Coherence: ${hrmState.global_coherence.toFixed(4)}\nFractal Score: ${hrmState.fractal_score.toFixed(4)}\nPrecision Score: ${hrmState.precision_score.toFixed(4)}\nOptimization Score: ${hrmState.optimization_score.toFixed(4)}\n[/HRM SYSTEM STATE REPORT]`;
        } catch (err) {
            console.error('HRM backend unavailable:', err);
        }

        const externalData = textToNumericArray(messageWithFileContext);
        const simResult = triggerCycle(externalData);

        if (!simResult) {
            addMessageToCurrentThread({
                role: Role.BOT,
                content: `The simulation is currently busy. This shouldn't happen.`,
            });
            setIsLoading(false);
            setSimulationSpeed(prevSpeed);
            return;
        }

        updateCurrentThreadSimulationState(simulationService.saveState());

        if (simResult.error) {
            addMessageToCurrentThread({
                role: Role.BOT,
                content: `A cognitive matrix fluctuation occurred: ${simResult.error}`,
            });
            setIsLoading(false);
            setSimulationSpeed(prevSpeed);
            return;
        }

        const simReport = formatSystemReport(simResult);

        const messageToBot = `${hrmReport}\n\n${simReport}\n\n${messageWithFileContext}`;

        try {
            const stream = await sendMessageToBot(messageToBot, currentHistory, settings.ai);
            let fullBotResponse = '';

            addMessageToCurrentThread({ role: Role.BOT, content: '' });

            for await (const chunk of stream) {
                fullBotResponse += chunk.text;

                updateThread(currentThreadId!, {
                    messages: [
                        ...currentThread.messages,
                        { id: crypto.randomUUID(), role: Role.USER, content: uiMessageContent },
                        { id: crypto.randomUUID(), role: Role.BOT, content: fullBotResponse },
                    ],
                });
            }

            speak(stripMarkdown(fullBotResponse));
        } catch (error: any) {
            console.error('An error occurred during chat:', error);
            const errorMessage = error.message || 'An unknown error occurred';
            addMessageToCurrentThread({
                role: Role.BOT,
                content: `My connection to the generative stream was disrupted. Please try again.\n\n*${errorMessage}*`,
            });
        } finally {
            setIsLoading(false);
            setSimulationSpeed(prevSpeed);
        }
    }, [
        isLoading,
        triggerCycle,
        speak,
        cancelSpeech,
        currentThread,
        settings.ai,
        addMessageToCurrentThread,
        updateCurrentThreadSimulationState,
        updateThread,
        currentThreadId,
        simulationSpeed,
        setSimulationSpeed,
    ]);

    return (
        <div
            className={`h-screen w-screen overflow-hidden relative ${
                settings.theme.theme === 'light' ? 'light-theme' : 'dark-theme'
            }`}
        >
            <SimulationVisualizer />
            {isSettingsOpen && (
                <SettingsPanel 
                    settings={settings}
                    onChange={setSettings}
                    onClose={() => setIsSettingsOpen(false)}
                    onResetSimulation={resetSimulation}
                />
            )}

            <div className="relative z-10 flex flex-col h-full w-full p-4 gap-4">
                <Header onOpenSettings={() => setIsSettingsOpen(true)} onOpenThreads={() => setIsThreadsOpen(true)} />
                <MetricsDashboard config={{ ...settings.simulation, width: 50, height: 50 }} />
                <div className="flex-grow min-h-0">
                     <ChatInterface 
                        messages={currentThread?.messages || []}
                        onSend={handleSend}
                        isLoading={isLoading}
                        systemNotification={systemNotification}
                        isListening={isListening}
                        transcript={transcript}
                        startListening={startListening}
                        stopListening={stopListening}
                        hasSpeechRecognition={hasSpeechRecognition}
                     />
                </div>
            </div>

            {isThreadsOpen && (
                <ThreadsPanel
                    threads={threads}
                    currentThreadId={currentThreadId}
                    onCreateThread={createThread}
                    onSwitchThread={switchThread}
                    onDeleteThread={deleteThread}
                    isOpen={isThreadsOpen}
                    onClose={() => setIsThreadsOpen(false)}
                />
            )}
        </div>
    );
}
