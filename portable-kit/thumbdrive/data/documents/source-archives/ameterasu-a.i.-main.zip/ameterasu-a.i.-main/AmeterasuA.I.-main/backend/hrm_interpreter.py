# backend/hrm_interpreter.py
import math
import random
import uuid
from dataclasses import dataclass, field, asdict
from typing import Any, Dict, List, Optional


@dataclass
class ActiveState:
    id: str
    value: float
    channel: int
    domain: int
    layer: int = 0
    theta: float = 0.0
    state_vector: List[float] = field(default_factory=lambda: [0.0] * 24)
    coherence: float = 0.0
    energy: float = 1.0
    age: int = 0
    tags: List[str] = field(default_factory=list)


@dataclass
class Runtime:
    num_channels: int = 12
    num_domains: int = 22
    num_layers: int = 14

    theta: float = 0.0
    omega: float = 0.045
    steps: int = 0
    optimization_score: float = 0.0

    active_states: List[ActiveState] = field(default_factory=list)
    memory_bank: Dict[str, Any] = field(default_factory=dict)

    fields: Dict[str, List[List[float]]] = field(default_factory=dict)

    def __post_init__(self):
        if not self.fields:
            self.fields = {
                "global_phi": [[random.uniform(-0.05, 0.05) for _ in range(self.num_domains)] for _ in range(self.num_channels)],
                "coherence": [[0.0 for _ in range(self.num_domains)] for _ in range(self.num_channels)],
                "oscillator_phase": [[0.0 for _ in range(self.num_domains)] for _ in range(self.num_channels)],
                "oscillator_freq": [[1.0 for _ in range(self.num_domains)] for _ in range(self.num_channels)],
                "oscillator_amp": [[0.5 for _ in range(self.num_domains)] for _ in range(self.num_channels)],
            }

        if not self.active_states:
            for ch in range(self.num_channels):
                for dm in range(2):  # start smaller; scale later
                    self.active_states.append(
                        ActiveState(
                            id=str(uuid.uuid4()),
                            value=random.uniform(-0.2, 0.2),
                            channel=ch,
                            domain=(ch + dm) % self.num_domains,
                            layer=(ch + dm) % self.num_layers,
                            state_vector=[random.uniform(-0.1, 0.1) for _ in range(24)],
                            coherence=0.5,
                            energy=0.5,
                        )
                    )

    def update_cycle(self):
        self.theta = (self.theta + self.omega + 0.0025 * math.sin(self.steps * 0.01)) % (2 * math.pi)

    def text_to_signal(self, text: str, length: int = 24) -> List[float]:
        vec = [0.0] * length
        if not text:
            return vec
        for i, ch in enumerate(text):
            vec[i % length] += ord(ch) / 255.0
        m = max(1e-8, max(abs(x) for x in vec))
        return [x / m for x in vec]

    def update_field(self, user_signal: List[float]):
        signal_mean = sum(user_signal) / len(user_signal) if user_signal else 0.0

        for ch in range(self.num_channels):
            for dm in range(self.num_domains):
                phi = self.fields["global_phi"][ch][dm]
                lap_proxy = 0.0

                neighbors = [
                    ((ch - 1) % self.num_channels, dm),
                    ((ch + 1) % self.num_channels, dm),
                    (ch, (dm - 1) % self.num_domains),
                    (ch, (dm + 1) % self.num_domains),
                ]
                for nch, ndm in neighbors:
                    lap_proxy += self.fields["global_phi"][nch][ndm] - phi

                nonlocal_term = 0.1 * (
                    self.fields["global_phi"][(ch + 3) % self.num_channels][(dm + 5) % self.num_domains] - phi
                )

                manifold_drive = 0.08 * math.sin(self.theta) + 0.06 * signal_mean

                dphi = (
                    0.16 * lap_proxy
                    + 0.08 * phi
                    - 0.04 * abs(phi) * phi * phi
                    - 0.02 * phi
                    + nonlocal_term
                    + manifold_drive
                )

                self.fields["global_phi"][ch][dm] = max(-3.0, min(3.0, phi + 0.045 * dphi))

    def update_states(self, user_signal: List[float]):
        signal_mean = sum(user_signal) / len(user_signal) if user_signal else 0.0
        mean_vec = [0.0] * 24

        for i in range(24):
            if self.active_states:
                mean_vec[i] = sum(st.state_vector[i] for st in self.active_states) / len(self.active_states)

        for st in self.active_states:
            local_phi = self.fields["global_phi"][st.channel][st.domain]

            for i in range(24):
                self_term = st.state_vector[i]
                bounded_growth = 0.08 * self_term * (1 - (self_term * self_term) / (2.2 * 2.2))
                consensus = 0.05 * (mean_vec[i] - self_term)
                field_term = 0.03 * local_phi * math.cos(self.theta + i * 0.17)
                signal_term = 0.02 * signal_mean

                st.state_vector[i] = max(-2.2, min(2.2, self_term + bounded_growth + consensus + field_term + signal_term))

            norm = math.sqrt(sum(v * v for v in st.state_vector))
            mean_norm = math.sqrt(sum(v * v for v in mean_vec)) + 1e-8
            dot = sum(a * b for a, b in zip(st.state_vector, mean_vec))
            st.coherence = max(0.0, min(1.0, (dot / ((norm * mean_norm) + 1e-8) + 1.0) / 2.0))
            st.energy = max(0.0, min(1.5, 0.35 + 0.15 * norm / math.sqrt(24) + 0.2 * abs(local_phi)))
            st.theta = self.theta
            st.age += 1

    def route_topology(self):
        for st in self.active_states:
            phase_band = int((self.theta / (2 * math.pi)) * self.num_channels) % self.num_channels
            st.channel = (st.channel + phase_band + (1 if st.coherence > 0.55 else 0)) % self.num_channels
            st.domain = (st.domain + (1 if st.energy > 0.6 else 0)) % self.num_domains
            st.layer = (st.layer + (1 if st.coherence > st.energy * 0.5 else 0)) % self.num_layers

    def compute_objective(self) -> Dict[str, float]:
        phi_vals = [x for row in self.fields["global_phi"] for x in row]
        phi_mean = sum(phi_vals) / len(phi_vals) if phi_vals else 0.0
        phi_var = sum((x - phi_mean) ** 2 for x in phi_vals) / len(phi_vals) if phi_vals else 0.0

        coherence_vals = [st.coherence for st in self.active_states]
        energy_vals = [st.energy for st in self.active_states]

        global_coherence = sum(coherence_vals) / len(coherence_vals) if coherence_vals else 0.0
        mean_energy = sum(energy_vals) / len(energy_vals) if energy_vals else 0.0

        F_fractal = 1.0 / (1.0 + abs(phi_var - 0.18))
        F_precision = 1.0 / (1.0 + abs(phi_mean - 0.5))
        F_stability = 1.0 / (1.0 + 6.0 * phi_var)
        F_coherence = global_coherence
        R = max(0.0, mean_energy - 1.1)

        score = (
            0.22 * F_fractal
            + 0.24 * F_precision
            + 0.28 * F_stability
            + 0.26 * F_coherence
            - 0.18 * R
        )

        self.optimization_score = score

        return {
            "fractal_score": F_fractal,
            "precision_score": F_precision,
            "stability": F_stability,
            "global_coherence": F_coherence,
            "penalty": R,
            "optimization_score": score,
        }

    def step(self, user_text: str) -> Dict[str, Any]:
        self.update_cycle()
        signal = self.text_to_signal(user_text)
        self.update_field(signal)
        self.update_states(signal)
        self.route_topology()
        metrics = self.compute_objective()
        self.steps += 1

        active_channel = int((self.theta / (2 * math.pi)) * self.num_channels) % self.num_channels
        active_domain = int((self.theta / (2 * math.pi)) * self.num_domains) % self.num_domains
        active_layer = int((self.theta / (2 * math.pi)) * self.num_layers) % self.num_layers

        return {
            "time": self.steps,
            "theta": self.theta,
            "activeChannel": active_channel,
            "activeDomain": active_domain,
            "activeLayer": active_layer,
            **metrics,
        }