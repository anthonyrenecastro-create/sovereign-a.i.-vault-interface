import React, { useState } from 'react';
import type { Thread } from '../types';

interface ThreadsPanelProps {
    threads: Thread[];
    currentThreadId: string | null;
    onCreateThread: (name?: string) => void;
    onSwitchThread: (threadId: string) => void;
    onDeleteThread: (threadId: string) => void;
    isOpen: boolean;
    onClose: () => void;
}

const ThreadsPanel: React.FC<ThreadsPanelProps> = ({
    threads,
    currentThreadId,
    onCreateThread,
    onSwitchThread,
    onDeleteThread,
    isOpen,
    onClose,
}) => {
    const [newThreadName, setNewThreadName] = useState('');

    if (!isOpen) return null;

    const handleCreateThread = () => {
        const name = newThreadName.trim() || undefined;
        onCreateThread(name);
        setNewThreadName('');
    };

    const formatDate = (timestamp: number) => {
        return new Date(timestamp).toLocaleString();
    };

    return (
        <div className="threads-panel-overlay" onClick={onClose}>
            <div className="threads-panel" onClick={e => e.stopPropagation()}>
                <div className="threads-panel-header">
                    <h3>Conversation Threads</h3>
                    <button onClick={onClose} className="close-button">×</button>
                </div>

                <div className="create-thread-section">
                    <input
                        type="text"
                        placeholder="New thread name..."
                        value={newThreadName}
                        onChange={e => setNewThreadName(e.target.value)}
                        onKeyPress={e => e.key === 'Enter' && handleCreateThread()}
                    />
                    <button onClick={handleCreateThread}>Create</button>
                </div>

                <div className="threads-list">
                    {threads.map(thread => (
                        <div
                            key={thread.id}
                            className={`thread-item ${thread.id === currentThreadId ? 'active' : ''}`}
                            onClick={() => onSwitchThread(thread.id)}
                        >
                            <div className="thread-info">
                                <div className="thread-name">{thread.name}</div>
                                <div className="thread-meta">
                                    {thread.messages.length} messages • {formatDate(thread.updatedAt)}
                                </div>
                            </div>
                            <button
                                onClick={e => {
                                    e.stopPropagation();
                                    onDeleteThread(thread.id);
                                }}
                                className="delete-thread-button"
                                disabled={threads.length === 1}
                            >
                                🗑️
                            </button>
                        </div>
                    ))}
                </div>
            </div>

            <style jsx>{`
                .threads-panel-overlay {
                    position: fixed;
                    top: 0;
                    left: 0;
                    right: 0;
                    bottom: 0;
                    background: rgba(0, 0, 0, 0.5);
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    z-index: 1000;
                }

                .threads-panel {
                    background: white;
                    border-radius: 8px;
                    padding: 20px;
                    max-width: 500px;
                    width: 90%;
                    max-height: 80vh;
                    overflow-y: auto;
                    box-shadow: 0 4px 20px rgba(0, 0, 0, 0.15);
                }

                .threads-panel-header {
                    display: flex;
                    justify-content: space-between;
                    align-items: center;
                    margin-bottom: 20px;
                }

                .threads-panel-header h3 {
                    margin: 0;
                    color: #333;
                }

                .close-button {
                    background: none;
                    border: none;
                    font-size: 24px;
                    cursor: pointer;
                    color: #666;
                }

                .create-thread-section {
                    display: flex;
                    gap: 10px;
                    margin-bottom: 20px;
                }

                .create-thread-section input {
                    flex: 1;
                    padding: 8px 12px;
                    border: 1px solid #ddd;
                    border-radius: 4px;
                }

                .create-thread-section button {
                    padding: 8px 16px;
                    background: #007bff;
                    color: white;
                    border: none;
                    border-radius: 4px;
                    cursor: pointer;
                }

                .threads-list {
                    display: flex;
                    flex-direction: column;
                    gap: 10px;
                }

                .thread-item {
                    display: flex;
                    align-items: center;
                    padding: 12px;
                    border: 1px solid #ddd;
                    border-radius: 4px;
                    cursor: pointer;
                    transition: background-color 0.2s;
                }

                .thread-item:hover {
                    background: #f8f9fa;
                }

                .thread-item.active {
                    background: #e3f2fd;
                    border-color: #007bff;
                }

                .thread-info {
                    flex: 1;
                }

                .thread-name {
                    font-weight: 500;
                    color: #333;
                }

                .thread-meta {
                    font-size: 12px;
                    color: #666;
                    margin-top: 4px;
                }

                .delete-thread-button {
                    background: none;
                    border: none;
                    cursor: pointer;
                    padding: 4px;
                    border-radius: 4px;
                    transition: background-color 0.2s;
                }

                .delete-thread-button:hover {
                    background: #ffebee;
                }

                .delete-thread-button:disabled {
                    opacity: 0.5;
                    cursor: not-allowed;
                }
            `}</style>
        </div>
    );
};

export default ThreadsPanel;