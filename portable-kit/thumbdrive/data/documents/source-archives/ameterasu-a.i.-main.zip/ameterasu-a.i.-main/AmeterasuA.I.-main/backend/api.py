from fastapi import FastAPI
from pydantic import BaseModel
from fastapi.middleware.cors import CORSMiddleware
from .hrm_interpreter import Runtime

app = FastAPI()
runtime = Runtime()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

class InterpreterInput(BaseModel):
    text: str

@app.get("/health")
def health():
    return {"ok": True}

@app.post("/hrm/step")
def hrm_step(payload: InterpreterInput):
    result = runtime.step(payload.text)
    return result
