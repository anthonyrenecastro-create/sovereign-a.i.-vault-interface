// services/interpreterService.ts
export interface HRMResponse {
  time: number;
  theta: number;
  activeChannel: number;
  activeDomain: number;
  activeLayer: number;
  stability: number;
  global_coherence: number;
  fractal_score: number;
  precision_score: number;
  optimization_score: number;
  penalty: number;
}

const API_BASE = 'http://127.0.0.1:8000';

export async function stepHRM(text: string, threadId: string): Promise<HRMResponse> {
  const res = await fetch(`${API_BASE}/hrm/step`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ text, thread_id: threadId }),
  });

  if (!res.ok) {
    throw new Error(`HRM API error: ${res.status}`);
  }

  return res.json();
}