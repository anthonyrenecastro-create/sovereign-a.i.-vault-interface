import { useState, useRef, useCallback, useEffect } from 'react';
import simulationService from '../services/simulationService';
import type { SimulationOutput, SimulationData, HistoryData, SimulationConfig } from '../types';

const getInitialState = (): SimulationData => {
  const sim = simulationService;
  return {
    metrics: {
      mean_ameterasu: 0,
      mean_matter: 0,
      mean_gauge: 0,
      energy_density: 0,
      chaos_metric: 0,
      stability: 0,
      mi_loss: 0,
      theta: 0,
      global_coherence: 0,
      fractal_score: 0,
      optimization_score: 0,
    },
    fields: {
      matter: sim.field.matter_field,
      gauge: sim.field.gauge_field,
      ameterasu: sim.field.ameterasu_field,
    },
    parameters: {
      mass: sim.field.mass,
      coupling: sim.field.coupling,
      learningRate: sim.mi.learning_rate,
      time: 0,
    },
  };
};

export const useSimulation = (config: SimulationConfig) => {
  const simulationRef = useRef(simulationService);
  const [simulationData, setSimulationData] = useState<SimulationData>(() => getInitialState());
  const [isRunning, setIsRunning] = useState(false);
  const [simulationSpeed, setSimulationSpeed] = useState(1); // 1 = normal, >1 = slower
  const timerRef = useRef<NodeJS.Timeout | null>(null);
  const [history, setHistory] = useState<HistoryData[]>([]);

  const runCycle = useCallback((external_data: number[] = []) => {
    const newData: SimulationOutput = simulationRef.current.run_cycle(external_data);

    if (!newData.error) {
      setSimulationData({
        metrics: {
          stability: newData.stability,
          mi_loss: newData.mi_feedback.mi_loss,
          energy_density: newData.patterns.energy_density,
          chaos_metric: newData.patterns.chaos_metric,
          mean_ameterasu: newData.patterns.mean_ameterasu,
          mean_matter: newData.patterns.mean_matter,
          mean_gauge: newData.patterns.mean_gauge,
          theta: newData.hrm.theta,
          global_coherence: newData.hrm.globalCoherence,
          fractal_score: newData.hrm.fractalScore,
          optimization_score: newData.hrm.optimizationScore,
        },
        parameters: {
          time: newData.time,
          mass: simulationRef.current.field.mass,
          coupling: simulationRef.current.field.coupling,
          learningRate: simulationRef.current.mi.learning_rate,
        },
        fields: newData.fields,
      });

      setHistory(prev => {
        const entry: HistoryData = {
          time: newData.time,
          stability: newData.stability,
          mi_loss: newData.mi_feedback.mi_loss,
          energy_density: newData.patterns.energy_density,
          theta: newData.hrm.theta,
          optimization_score: newData.hrm.optimizationScore,
        };
        const next = [...prev, entry];
        return next.length > 200 ? next.slice(-200) : next;
      });
    }

    return newData;
  }, []);


  const simulationLoop = useCallback(() => {
    runCycle([]);
    timerRef.current = setTimeout(simulationLoop, 1000 / simulationSpeed);
  }, [runCycle, simulationSpeed]);


  const startSimulation = useCallback(() => {
    if (isRunning) return;
    setIsRunning(true);
    timerRef.current = setTimeout(simulationLoop, 1000 / simulationSpeed);
  }, [isRunning, simulationLoop, simulationSpeed]);


  const stopSimulation = useCallback(() => {
    if (!isRunning) return;
    setIsRunning(false);
    if (timerRef.current) {
      clearTimeout(timerRef.current);
      timerRef.current = null;
    }
  }, [isRunning]);

  const stepSimulation = useCallback(() => {
    if (isRunning) return;
    runCycle([]);
  }, [isRunning, runCycle]);

  const triggerCycle = useCallback((external_data: number[]): SimulationOutput | null => {
    if (isRunning) return null;
    return runCycle(external_data);
  }, [isRunning, runCycle]);

  const resetSimulation = useCallback(() => {
    stopSimulation();
    simulationRef.current.reset(config);
    setSimulationData(getInitialState());
    setHistory([]);
  }, [stopSimulation, config]);

  useEffect(() => {
    simulationRef.current.field.syntropy_target = config.syntropyTarget;
  }, [config.syntropyTarget]);

  useEffect(() => {
    resetSimulation();
  }, [config.initialMass, config.initialCoupling, config.width, config.height, resetSimulation]);

  return {
    simulationData,
    isRunning,
    startSimulation,
    stopSimulation,
    resetSimulation,
    stepSimulation,
    triggerCycle,
    history,
    simulationSpeed,
    setSimulationSpeed,
  };
};