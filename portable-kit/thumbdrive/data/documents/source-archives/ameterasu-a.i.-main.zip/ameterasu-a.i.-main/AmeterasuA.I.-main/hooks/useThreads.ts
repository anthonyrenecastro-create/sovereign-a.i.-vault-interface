import { useState, useEffect, useCallback } from 'react';
import type { Thread, Message, SimulationState } from '../types';
import { THREADS_KEY, CURRENT_THREAD_KEY } from '../constants';

const generateId = () => Math.random().toString(36).substr(2, 9);

const createNewThread = (name?: string): Thread => {
    const now = Date.now();
    return {
        id: generateId(),
        name: name || `Thread ${new Date().toLocaleString()}`,
        messages: [],
        simulationState: {} as SimulationState, // Will be initialized when needed
        createdAt: now,
        updatedAt: now,
    };
};

export const useThreads = () => {
    const [threads, setThreads] = useState<Thread[]>([]);
    const [currentThreadId, setCurrentThreadId] = useState<string | null>(null);

    // Load threads from localStorage
    useEffect(() => {
        const savedThreads = localStorage.getItem(THREADS_KEY);
        const savedCurrentThread = localStorage.getItem(CURRENT_THREAD_KEY);

        if (savedThreads) {
            try {
                const parsedThreads = JSON.parse(savedThreads);
                setThreads(parsedThreads);
            } catch (e) {
                console.error('Failed to parse saved threads:', e);
            }
        }

        if (savedCurrentThread) {
            setCurrentThreadId(savedCurrentThread);
        } else if (threads.length === 0) {
            // Create initial thread if none exist
            const initialThread = createNewThread('Main Conversation');
            setThreads([initialThread]);
            setCurrentThreadId(initialThread.id);
        }
    }, []);

    // Save threads to localStorage whenever they change
    useEffect(() => {
        if (threads.length > 0) {
            localStorage.setItem(THREADS_KEY, JSON.stringify(threads));
        }
    }, [threads]);

    // Save current thread ID
    useEffect(() => {
        if (currentThreadId) {
            localStorage.setItem(CURRENT_THREAD_KEY, currentThreadId);
        }
    }, [currentThreadId]);

    const getCurrentThread = useCallback((): Thread | null => {
        return threads.find(t => t.id === currentThreadId) || null;
    }, [threads, currentThreadId]);

    const createThread = useCallback((name?: string): Thread => {
        const newThread = createNewThread(name);
        setThreads(prev => [...prev, newThread]);
        setCurrentThreadId(newThread.id);
        return newThread;
    }, []);

    const switchThread = useCallback((threadId: string) => {
        if (threads.find(t => t.id === threadId)) {
            setCurrentThreadId(threadId);
        }
    }, [threads]);

    const updateThread = useCallback((threadId: string, updates: Partial<Thread>) => {
        setThreads(prev => prev.map(thread =>
            thread.id === threadId
                ? { ...thread, ...updates, updatedAt: Date.now() }
                : thread
        ));
    }, []);

    const addMessageToCurrentThread = useCallback((message: Omit<Message, 'id' | 'timestamp'>) => {
        if (!currentThreadId) return;

        const newMessage: Message = {
            ...message,
            id: generateId(),
            timestamp: Date.now(),
        };

        setThreads(prev => prev.map(thread =>
            thread.id === currentThreadId
                ? {
                    ...thread,
                    messages: [...thread.messages, newMessage],
                    updatedAt: Date.now()
                }
                : thread
        ));
    }, [currentThreadId]);

    const updateCurrentThreadSimulationState = useCallback((simulationState: SimulationState) => {
        if (!currentThreadId) return;

        updateThread(currentThreadId, { simulationState });
    }, [currentThreadId, updateThread]);

    const deleteThread = useCallback((threadId: string) => {
        setThreads(prev => prev.filter(t => t.id !== threadId));
        if (currentThreadId === threadId) {
            const remaining = threads.filter(t => t.id !== threadId);
            setCurrentThreadId(remaining.length > 0 ? remaining[0].id : null);
        }
    }, [currentThreadId, threads]);

    const searchMessages = useCallback((query: string): { thread: Thread; message: Message }[] => {
        const results: { thread: Thread; message: Message }[] = [];
        const lowerQuery = query.toLowerCase();

        threads.forEach(thread => {
            thread.messages.forEach(message => {
                if (message.content.toLowerCase().includes(lowerQuery)) {
                    results.push({ thread, message });
                }
            });
        });

        return results;
    }, [threads]);

    return {
        threads,
        currentThreadId,
        currentThread: getCurrentThread(),
        createThread,
        switchThread,
        updateThread,
        addMessageToCurrentThread,
        updateCurrentThreadSimulationState,
        deleteThread,
        searchMessages,
    };
};