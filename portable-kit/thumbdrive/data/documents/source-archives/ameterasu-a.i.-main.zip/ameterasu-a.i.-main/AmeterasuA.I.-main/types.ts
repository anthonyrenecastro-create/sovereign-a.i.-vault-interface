import type { Content } from '@google/genai';

// Core Types for Chat
export enum Role {
  USER = 'user',
  BOT = 'model',
}

export interface Message {
  id: string;
  role: Role;
  content: string;
}

// Settings
export interface AiSettings {
  temperature: number;
  maxOutputTokens: number;
}

export interface SimulationSettings {
  syntropyTarget: number;
  initialMass: number;
  initialCoupling: number;
}

export interface AppSettings {
  ai: AiSettings;
  simulation: SimulationSettings;
}

// ---------------- HRM TYPES ----------------

export interface HRMGuna {
  s: number;
  r: number;
  t: number;
}

export interface HRMNodeState {
  channel: number;   // 0..11
  domain: number;    // 0..21
  layer: number;     // 0..13
  state_vector: number[]; // len 24
  guna: HRMGuna;
  local_coherence: number;
  local_energy: number;
}

export interface HRMSnapshot {
  theta: number;
  activeChannel: number;
  activeDomain: number;
  activeLayer: number;
  globalCoherence: number;
  globalStability: number;
  fractalScore: number;
  precisionScore: number;
  optimizationScore: number;
}

export interface SimulationState {
  time: number;
  theta: number;
  fieldMass: number;
  fieldCoupling: number;
  fieldGrid: number[][];
  stateGrid: HRMNodeState[];
  patterns: any[];
}

export interface SimulationConfig {
  syntropyTarget: number;
  initialMass: number;
  initialCoupling: number;
  width: number;
  height: number;
}

export interface SimulationOutput {
  substrate: string;
  time: number;
  stability: number;
  patterns: {
    [key: string]: number;
  };
  mi_feedback: {
    mi_loss: number;
    mass_adjustment: number;
    coupling_adjustment: number;
  };
  fields: {
    matter: number[][];
    gauge: number[][];
    ameterasu: number[][];
  };
  hrm: HRMSnapshot;
  error?: string;
}

// Gemini
export type GeminiHistory = Content[];

// UI-facing structures
export interface SimulationMetrics {
  stability: number;
  mi_loss: number;
  energy_density: number;
  chaos_metric: number;
  mean_ameterasu: number;
  mean_matter: number;
  mean_gauge: number;
  theta: number;
  global_coherence: number;
  fractal_score: number;
  optimization_score: number;
}

export interface SimulationParameters {
  time: number;
  mass: number;
  coupling: number;
  learningRate: number;
}

export interface HistoryData {
  time: number;
  stability: number;
  mi_loss: number;
  energy_density: number;
  theta: number;
  optimization_score: number;
}

export interface SimulationData {
  metrics: SimulationMetrics;
  parameters: SimulationParameters;
  fields: {
    matter: number[][];
    gauge: number[][];
    ameterasu: number[][];
  };
}
