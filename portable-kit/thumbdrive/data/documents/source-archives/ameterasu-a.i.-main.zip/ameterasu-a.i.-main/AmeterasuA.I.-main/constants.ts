export const CHAT_HISTORY_KEY = 'ameterasu_chat_history_v3';
export const SIMULATION_STATE_KEY = 'ameterasu_simulation_state_v3';
export const SETTINGS_KEY = 'ameterasu_settings_v2';
export const THREADS_KEY = 'ameterasu_threads_v1';
export const CURRENT_THREAD_KEY = 'ameterasu_current_thread_v1';
