import React from 'react';
import { useSimulation } from '../hooks/useSimulation';

interface MetricsDashboardProps {
    config: {
        syntropyTarget: number;
        initialMass: number;
        initialCoupling: number;
        width: number;
        height: number;
    };
}

const MetricsDashboard: React.FC<MetricsDashboardProps> = ({ config }) => {
    const { simulationData } = useSimulation(config);

    const getCyclePhase = (time: number): string => {
        const phases = ['Initialization', 'Matter Update', 'Gauge Update', 'Ameterasu Update', 'MI Learning'];
        return phases[time % phases.length];
    };

    return (
        <div className="bg-gray-800 text-white p-4 rounded-lg shadow-lg">
            <h2 className="text-lg font-bold mb-4">System Metrics Dashboard</h2>
            <div className="space-y-2">
                <div className="flex justify-between">
                    <span>State coherence:</span>
                    <span className="font-mono">{simulationData.metrics.stability.toFixed(4)}</span>
                </div>
                <div className="flex justify-between">
                    <span>Active domain:</span>
                    <span className="font-mono">reasoning</span>
                </div>
                <div className="flex justify-between">
                    <span>Cycle phase:</span>
                    <span className="font-mono">{getCyclePhase(simulationData.parameters.time)}</span>
                </div>
            </div>
        </div>
    );
};

export default MetricsDashboard;
